#this file will contain the code to create, upload, files to github and google directory

from fastapi import FastAPI, Form
import requests
import os
import glob
from dotenv import load_dotenv
from google.oauth2 import service_account
from googleapiclient.discovery import build
from googleapiclient.http import MediaFileUpload

load_dotenv()

app = FastAPI()

# Configuration
GITHUB_TOKEN = os.getenv("GITHUB_TOKEN")
WORKFLOW_REPO = os.getenv("WORKFLOW_REPO")
TARGET_REPO = os.getenv("TARGET_REPO")
WORKFLOW_FILENAME = os.getenv("WORKFLOW_FILENAME")
GITHUB_OWNER = os.getenv("GITHUB_OWNER")


SERVICE_ACCOUNT_FILE = "credentials.json"
SCOPES = ["https://www.googleapis.com/auth/drive.file"]

PARENT_ID = "1PfhsHAnqHtjSF90qJ8Oz4WknEgUOvdCU"
SHARE_WITH_EMAIL = "helix@adobe.com"

# Dictionary to store folder mappings
folder_storage = {}

# Dictionary to store branch mappings
branch_storage = {}


def create_drive_folder(username: str) -> dict:
    """Creates a Google Drive folder and a 'Global' subfolder, stores the folder_id."""
    try:
        print(f"Creating Google Drive folders for project: {username}")
        print(f"Current working directory: {os.getcwd()}")
        print(f"Service account file path: {SERVICE_ACCOUNT_FILE}")
        print(f"Service account file exists: {os.path.exists(SERVICE_ACCOUNT_FILE)}")
        
        # Check if the credentials file exists
        if not os.path.exists(SERVICE_ACCOUNT_FILE):
            raise FileNotFoundError(f"Service account file not found: {SERVICE_ACCOUNT_FILE}")
        
        # Initialize the Drive API client
        creds = service_account.Credentials.from_service_account_file(SERVICE_ACCOUNT_FILE, scopes=SCOPES)
        drive_service = build("drive", "v3", credentials=creds)
        
        # Verify if the parent folder exists
        try:
            drive_service.files().get(fileId=PARENT_ID).execute()
            print(f"Parent folder exists with ID: {PARENT_ID}")
        except Exception as e:
            print(f"Warning: Parent folder check failed: {str(e)}")
        
        # Create the main folder for the user
        folder_metadata = {"name": username, "mimeType": "application/vnd.google-apps.folder", "parents": [PARENT_ID]}
        user_folder = drive_service.files().create(body=folder_metadata, fields="id").execute()
        user_folder_id = user_folder.get("id")
        print(f"Created main folder with ID: {user_folder_id}")

        # Create the "Global" subfolder inside the user folder
        global_folder_metadata = {"name": "Global", "mimeType": "application/vnd.google-apps.folder", "parents": [user_folder_id]}
        global_folder = drive_service.files().create(body=global_folder_metadata, fields="id").execute()
        global_folder_id = global_folder.get("id")
        print(f"Created Global subfolder with ID: {global_folder_id}")

        # Share both folders with AEM Helix if email is provided
        if SHARE_WITH_EMAIL:
            try:
                share_with_helix(user_folder_id, SHARE_WITH_EMAIL, creds)
                share_with_helix(global_folder_id, SHARE_WITH_EMAIL, creds)
                print(f"Shared folders with {SHARE_WITH_EMAIL}")
            except Exception as share_error:
                print(f"Warning: Failed to share folders: {str(share_error)}")
        
        # Store folder ID for later retrieval
        folder_storage["latest_folder_id"] = user_folder_id

        return {
            "folder_id": user_folder_id,
            "folder_url": f"https://drive.google.com/drive/folders/{user_folder_id}",
            "global_folder_id": global_folder_id,
            "global_folder_url": f"https://drive.google.com/drive/folders/{global_folder_id}",
        }
    except Exception as e:
        print(f"Error in create_drive_folder: {str(e)}")
        raise


def share_with_helix(file_id: str, user_email: str, creds) -> None:
    """Shares the created Google Drive folder with AEM Helix"""
    try:
        drive_service = build("drive", "v3", credentials=creds)
        permission = {"type": "user", "role": "writer", "emailAddress": user_email}
        drive_service.permissions().create(fileId=file_id, body=permission, sendNotificationEmail=False).execute()
        print(f"Successfully shared {file_id} with {user_email}")
    except Exception as e:
        print(f"Error sharing {file_id} with {user_email}: {str(e)}")
        raise


async def upload_folder_to_drive(local_path: str, folder_id:str) -> list:
    """Uploads all files from a local folder to Google Drive and converts Microsoft files."""
    creds = service_account.Credentials.from_service_account_file(SERVICE_ACCOUNT_FILE, scopes=SCOPES)
    drive_service = build("drive", "v3", credentials=creds)

    # Retrieve the most recently created folder ID
    if not folder_storage:
        return {"error": "No folder found. Please create a folder first."}

    folder_id = folder_id

    uploaded_files = []

    for file_path in glob.glob(f"{local_path}/**", recursive=True):
        if os.path.isfile(file_path):
            file_name = os.path.basename(file_path)
            media = MediaFileUpload(file_path)
            file_metadata = {"name": file_name, "parents": [folder_id]}

            uploaded_file = drive_service.files().create(body=file_metadata, media_body=media, fields="id, webViewLink").execute()

            # Convert Microsoft files to Google-native formats
            if file_name.endswith(".docx"):
                uploaded_file = drive_service.files().copy(fileId=uploaded_file["id"], body={"mimeType": "application/vnd.google-apps.document"}).execute()
            elif file_name.endswith(".xlsx"):
                uploaded_file = drive_service.files().copy(fileId=uploaded_file["id"], body={"mimeType": "application/vnd.google-apps.spreadsheet"}).execute()
            elif file_name.endswith(".pptx"):
                uploaded_file = drive_service.files().copy(fileId=uploaded_file["id"], body={"mimeType": "application/vnd.google-apps.presentation"}).execute()

            uploaded_files.append({"file_url": uploaded_file.get("webViewLink")})

    return uploaded_files


async def upload_folder_to_drive_with_dynamic_folder_id(local_path: str, folder_id: str) -> list:
    """Uploads all files from a local folder to Google Drive and converts Microsoft files."""
    creds = service_account.Credentials.from_service_account_file(SERVICE_ACCOUNT_FILE, scopes=SCOPES)
    drive_service = build("drive", "v3", credentials=creds)

    uploaded_files = []

    for file_path in glob.glob(f"{local_path}/**", recursive=True):
        if os.path.isfile(file_path):
            file_name = os.path.basename(file_path)
            media = MediaFileUpload(file_path)
            file_metadata = {"name": file_name, "parents": [folder_id]}

            uploaded_file = drive_service.files().create(body=file_metadata, media_body=media, fields="id, webViewLink").execute()

            # Convert Microsoft files to Google-native formats
            if file_name.endswith(".docx"):
                uploaded_file = drive_service.files().copy(fileId=uploaded_file["id"], body={"mimeType": "application/vnd.google-apps.document"}).execute()
            elif file_name.endswith(".xlsx"):
                uploaded_file = drive_service.files().copy(fileId=uploaded_file["id"], body={"mimeType": "application/vnd.google-apps.spreadsheet"}).execute()
            elif file_name.endswith(".pptx"):
                uploaded_file = drive_service.files().copy(fileId=uploaded_file["id"], body={"mimeType": "application/vnd.google-apps.presentation"}).execute()

            uploaded_files.append({"file_url": uploaded_file.get("webViewLink")})

    return uploaded_files


async def upload_file_to_drive(local_path: str, folder_id: str) -> dict:
    """Uploads a file from local system to Google Drive and converts if necessary"""
    try:
        print(f"Uploading file: {local_path} to folder ID: {folder_id}")
        
        # Validate local path
        if not local_path or not os.path.exists(local_path):
            print(f"Error: File not found at path {local_path}")
            return {
                "file_id": "error_file_id",
                "file_url": "#",
                "error": f"File not found at path {local_path}"
            }
            
        # Validate folder ID
        if not folder_id or folder_id == "default_folder_id" or folder_id == "error_folder_id":
            print(f"Warning: Using potentially invalid folder ID: {folder_id}")
            
        # Initialize Google Drive API client
        creds = service_account.Credentials.from_service_account_file(SERVICE_ACCOUNT_FILE, scopes=SCOPES)
        drive_service = build("drive", "v3", credentials=creds)

        file_name = os.path.basename(local_path)
        media = MediaFileUpload(local_path)
        file_metadata = {"name": file_name, "parents": [folder_id]}

        # Upload the file
        uploaded_file = drive_service.files().create(
            body=file_metadata, 
            media_body=media, 
            fields="id, webViewLink"
        ).execute()
        print(f"Successfully uploaded {file_name} with ID: {uploaded_file.get('id')}")

        # Convert Microsoft files to Google-native formats
        try:
            if file_name.endswith(".docx"):
                converted_file = drive_service.files().copy(
                    fileId=uploaded_file["id"], 
                    body={"mimeType": "application/vnd.google-apps.document"}
                ).execute()
                print(f"Converted {file_name} to Google Doc format")
            elif file_name.endswith(".xlsx"):
                converted_file = drive_service.files().copy(
                    fileId=uploaded_file["id"], 
                    body={"mimeType": "application/vnd.google-apps.spreadsheet"}
                ).execute()
                print(f"Converted {file_name} to Google Sheets format")
            elif file_name.endswith(".pptx"):
                converted_file = drive_service.files().copy(
                    fileId=uploaded_file["id"], 
                    body={"mimeType": "application/vnd.google-apps.presentation"}
                ).execute()
                print(f"Converted {file_name} to Google Slides format")
            else:
                converted_file = uploaded_file
                print(f"No conversion needed for {file_name}")
        except Exception as convert_error:
            print(f"Error converting file {file_name}: {str(convert_error)}")
            # If conversion fails, use the original uploaded file
            converted_file = uploaded_file

        return {
            "file_id": converted_file.get("id", uploaded_file.get("id", "error_id")),
            "file_url": converted_file.get("webViewLink", uploaded_file.get("webViewLink", "#")),
        }
    except Exception as e:
        print(f"Error uploading file {local_path}: {str(e)}")
        # Return a placeholder to avoid breaking the UI
        return {
            "file_id": "error_file_id",
            "file_url": "#",
            "error": str(e)
        }


def fetch_files_recursively():
    """Recursively fetches files and subfolders within a given Google Drive folder."""
    
    creds = service_account.Credentials.from_service_account_file(SERVICE_ACCOUNT_FILE, scopes=SCOPES)
    drive_service = build("drive", "v3", credentials=creds)

    folder_id = folder_storage.get("latest_folder_id")
    if not folder_id:
        return {"error": "No folder found. Please create a folder first."}

    results = drive_service.files().list(q=f"'{folder_id}' in parents", fields="files(id, name, mimeType, webViewLink)").execute()
    files = results.get("files", [])

    folder_contents = []

    for f in files:
        file_info = {"name": f["name"], "type": f["mimeType"], "file_url": f.get("webViewLink")}

        # If the file is a folder, fetch its contents recursively
        if f["mimeType"] == "application/vnd.google-apps.folder":
            file_info["contents"] = fetch_files_recursively(f["id"], drive_service)

        folder_contents.append(file_info)

    return folder_contents


def fetch_github_branch_files():
    """Fetches all files and folders from the given GitHub branch."""
    branch_url = branch_storage.get("latest_branch_url")
    if not branch_url:
        return {"error": "No branch found. Please create a folder first to generate a branch URL."}

    branch_name = branch_url.split("/")[-1]
    api_url = f"https://api.github.com/repos/{GITHUB_OWNER}/{TARGET_REPO}/git/trees/{branch_name}?recursive=1"
    
    headers = {"Authorization": f"token {GITHUB_TOKEN}", "Accept": "application/vnd.github.v3+json"}
    response = requests.get(api_url, headers=headers)
    
    if response.status_code != 200:
        return {"error": f"Failed to fetch files from branch: {response.text}"}
    
    data = response.json()
    return {"branch_files": [{"path": f["path"], "type": f["type"]} for f in data.get("tree", [])]}


async def create_folder_api(project_name):
    try:
        # Attempt to create the Google Drive folder
        folder_info = create_drive_folder(project_name)
        
        # If GitHub workflow integration is enabled
        if GITHUB_TOKEN and WORKFLOW_REPO and WORKFLOW_FILENAME:
            api_url = f"https://api.github.com/repos/{GITHUB_OWNER}/{WORKFLOW_REPO}/actions/workflows/{WORKFLOW_FILENAME}/dispatches"
            headers = {"Authorization": f"token {GITHUB_TOKEN}", "Accept": "application/vnd.github.v3+json"}
            data = {"ref": "main", "inputs": {"username": project_name, "folder_url": folder_info["folder_url"]}}

            response = requests.post(api_url, json=data, headers=headers)

            if response.status_code == 204:
                branch_url = f"https://github.com/{GITHUB_OWNER}/{TARGET_REPO}/tree/{project_name}"
                branch_storage["latest_branch_url"] = branch_url
                preview_url = f"https://{project_name}--{TARGET_REPO}--{GITHUB_OWNER}.aem.page"
                publish_url = f"https://{project_name}--{TARGET_REPO}--{GITHUB_OWNER}.aem.live"
                return {
                    "message": "Project Folder and 'Global' subfolder created successfully!",
                    "folder_id": folder_info["folder_id"],
                    "folder_url": folder_info["folder_url"],
                    "global_folder_id": folder_info["global_folder_id"],
                    "global_folder_url": folder_info["global_folder_url"],
                    "branch_url": branch_url,
                    "preview_url": preview_url,
                    "publish_url": publish_url,
                    "github_workflow_status": response.status_code,
                }
            else:
                # Return folder info even if GitHub workflow fails
                print(f"Warning: GitHub workflow failed with status {response.status_code}: {response.text}")
                return {
                    "message": "Google Drive folders created, but GitHub workflow failed.",
                    "folder_id": folder_info["folder_id"],
                    "folder_url": folder_info["folder_url"],
                    "global_folder_id": folder_info["global_folder_id"],
                    "global_folder_url": folder_info["global_folder_url"],
                    "github_workflow_status": response.status_code,
                    "github_error": response.text
                }
        else:
            # If GitHub integration is not configured, just return folder info
            return {
                "message": "Project Folder and 'Global' subfolder created successfully!",
                "folder_id": folder_info["folder_id"],
                "folder_url": folder_info["folder_url"],
                "global_folder_id": folder_info["global_folder_id"],
                "global_folder_url": folder_info["global_folder_url"]
            }
    except Exception as e:
        print(f"Error in create_folder_api: {str(e)}")
        # Return a dummy response that won't cause failures downstream
        return {
            "message": f"Error: {str(e)}",
            "folder_id": "error_folder_id",
            "folder_url": "#",
            "global_folder_id": "error_global_folder_id",
            "global_folder_url": "#",
            "error": str(e)
        }