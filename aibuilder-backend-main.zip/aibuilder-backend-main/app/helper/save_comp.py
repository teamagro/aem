import os
import re
import requests
import yaml
from dotenv import load_dotenv
from google import genai
from google.genai import types
import sys
sys.path.append(os.path.dirname(__file__))
from md_to_docx import md_to_docx, docx_to_html

# --- CONFIGURATION ---
BASE_URL = "https://sidekick-library--aem-block-collection--adobe.aem.page"
JSON_LIST_URL = "/tools/sidekick/library.json"
MD_DIR = "md_output"
HTML_DIR = os.path.join(MD_DIR, "html")
OUTPUT_YAML = "block_kb.yaml"

# Create directories
os.makedirs(MD_DIR, exist_ok=True)
os.makedirs(HTML_DIR, exist_ok=True)

# --- Custom YAML Dumper with proper indentation ---
class BlockDumper(yaml.Dumper):
    def increase_indent(self, flow=False, indentless=False):
        return super(BlockDumper, self).increase_indent(flow, False)

# Register a representer for strings to use the literal style | for multiline strings
def str_representer(dumper, data):
    # Always use '|' for multiline, never '|-'
    if '\n' in data:
        if not data.endswith('\n'):
            data += '\n'
        return dumper.represent_scalar('tag:yaml.org,2002:str', data, style='|')
    return dumper.represent_scalar('tag:yaml.org,2002:str', data)

# Register the representer
yaml.add_representer(str, str_representer, Dumper=BlockDumper)

# --- STEP 1: Download all markdowns ---
def get_list_of_urls(base_url, json_list_url):
    """Fetch the list of markdown endpoints from the remote JSON."""
    try:
        response = requests.get(base_url + json_list_url)
        response.raise_for_status()
        return response.json()
    except Exception as e:
        print(f"Could not process url {base_url+json_list_url}: {e}")
        return None

def download_all_markdowns(endpoint_list, base_url, out_path):
    """Download all markdown files and save as a single file."""
    with open(out_path, "w", encoding="utf-8") as fw:
        for endpoint in endpoint_list["data"]:
            full_url = base_url + endpoint["path"] + ".md"
            try:
                response = requests.get(full_url)
                response.raise_for_status()
                fw.write(response.text + "\n\n")
                print(f"Downloaded: {full_url}")
            except Exception as e:
                print(f"Failed to download {full_url}: {e}")

# --- STEP 2: Split combined markdown into component files ---
def split_components(input_path, output_dir):
    """Split the combined markdown file into individual component files, using the first 'name' field as filename. If a component does not have a name, use the first found name as fallback."""
    with open(input_path, "r", encoding="utf-8") as f:
        lines = f.readlines()
    components = []
    component_starts = [idx for idx, line in enumerate(lines) if re.match(r"\|\s*Library metadata\s*\|", line)]
    # Only add len(lines) if there is at least one component
    if component_starts:
        component_starts.append(len(lines))
    else:
        print("No components found in the markdown file.")
        return
    used_filenames = set()
    for i in range(len(component_starts) - 1):
        start = component_starts[i]
        end = component_starts[i+1]
        # Prevent the last component from capturing trailing content from previous components
        # Only include up to the next component's start, not the end of file if there is extra content
        # Remove trailing blank lines at the end of each component
        comp_lines = lines[start:end]
        while comp_lines and comp_lines[-1].strip() == '':
            comp_lines.pop()
        # Remove leading blank lines at the start of each component
        while comp_lines and comp_lines[0].strip() == '':
            comp_lines.pop(0)
        # If this is the last component, ensure it does not include content from previous components
        # by checking for the next 'Library metadata' after start
        if i == len(component_starts) - 2:
            # Find the next 'Library metadata' after start (should be none for last component)
            for j in range(start + 1, end):
                if re.match(r"\|\s*Library metadata\s*\|", lines[j]):
                    comp_lines = lines[start:j]
                    break
            # Remove trailing blank lines again if needed
            while comp_lines and comp_lines[-1].strip() == '':
                comp_lines.pop()
        # Find the first name field for filename in this component
        name = None
        for line in comp_lines:
            match = re.match(r"\|\s*name\s*\|\s*([^|]+)\|", line)
            if match:
                name = match.group(1).strip()
                break
        if name:
            base_filename = re.sub(r'[^\w\s-]', '', name).replace(' ', '_')
        else:
            base_filename = f"component_{i+1}"
            print(f"Warning: Component {i+1} has no name, using fallback '{base_filename}.md'")
        filename = base_filename + ".md"
        suffix = 1
        while filename in used_filenames or os.path.exists(os.path.join(output_dir, filename)):
            filename = f"{base_filename}_{suffix}.md"
            suffix += 1
        used_filenames.add(filename)
        filepath = os.path.join(output_dir, filename)
        with open(filepath, "w", encoding="utf-8") as out:
            out.writelines(comp_lines)
        print(f"Written: {filepath}")

# --- STEP 3: Extract metadata and body ---
def extract_metadata(lines):
    """Extract metadata from the component markdown lines."""
    metadata = {}
    in_table = False
    for line in lines:
        if re.match(r"\|\s*Library metadata\s*\|", line):
            in_table = True
            continue
        if in_table:
            if line.strip().startswith("+"):
                continue
            if not line.strip().startswith("|"):
                break
            parts = [p.strip() for p in line.strip().split("|")]
            if len(parts) >= 3 and parts[1] and parts[2]:
                metadata[parts[1]] = parts[2]
    return metadata

def extract_body(lines):
    """Extract the body (content) from the component markdown lines."""
    in_table = False
    after_table = False
    body_lines = []
    for line in lines:
        if re.match(r"\|\s*Library metadata\s*\|", line):
            in_table = True
            continue
        if in_table:
            if line.strip().startswith("+"):
                continue
            if not line.strip().startswith("|"):
                in_table = False
                after_table = True
        elif after_table:
            body_lines.append(line.rstrip("\n"))
    return body_lines

# --- STEP 4: Convert body to HTML ---
def ascii_table_to_html(body_lines):
    """Convert markdown body to HTML using md_to_docx and docx_to_html."""
    import tempfile
    import shutil
    body_md = "\n".join(body_lines).strip()
    with tempfile.TemporaryDirectory() as tmpdir:
        md_path = os.path.join(tmpdir, "temp.md")
        docx_path = os.path.join(tmpdir, "temp.docx")
        html_path = os.path.join(tmpdir, "temp.html")
        with open(md_path, "w", encoding="utf-8") as f:
            f.write(body_md)
        md_to_docx(md_path, docx_path)
        docx_to_html(docx_path, html_path)
        with open(html_path, "r", encoding="utf-8") as f:
            html = f.read()
        # Delete the temporary docx file after HTML is generated
        if os.path.exists(docx_path):
            os.remove(docx_path)
    return html

# --- STEP 5: Aggregate all data and output YAML ---
def build_yaml(md_dir, html_dir, output_yaml):
    """Aggregate all component data and output to YAML."""
    blocks = []
    for idx, filename in enumerate(sorted(os.listdir(md_dir)), 1):
        if filename.endswith(".md"):
            filepath = os.path.join(md_dir, filename)
            html_path = os.path.join(html_dir, filename.replace(".md", ".html"))
            with open(filepath, "r", encoding="utf-8") as f:
                lines = f.readlines()
            metadata = extract_metadata(lines)
            body_lines = extract_body(lines)
            body_md = "\n".join(body_lines).strip()
            body_html = ascii_table_to_html(body_lines)
            with open(html_path, "w", encoding="utf-8") as f:
                f.write(body_html)
            block = {
                "type": metadata.get("name", f"BlockType{idx:02d}"),
                "element": metadata.get("element", ""),
                "description": metadata.get("description", ""),
                "markdown": body_md,
                "html": body_html,
                "html_description": ""
            }
            blocks.append(block)
    # Use the custom YAML dumper with proper indentation
    with open(output_yaml, "w", encoding="utf-8") as f:
        yaml.dump({"blocks": blocks}, f,
                 Dumper=BlockDumper,
                 allow_unicode=True,
                 sort_keys=False,
                 default_flow_style=False,
                 indent=2,
                 width=120)

    print(f"Saved combined YAML to {output_yaml}")

# --- STEP 6: Enrich YAML with LLM ---
def enrich_yaml_with_llm(yaml_path):
    enriched_path = "block_kb_final.yaml"
    """Enrich the YAML file using Gemini LLM for type, description, and html_description."""
    load_dotenv()
    api_key = os.getenv("GEMINI_API_KEY")
    if not api_key:
        print("GEMINI_API_KEY not found in environment. Skipping LLM enrichment.")
        return

    client = genai.Client(api_key=api_key)

    with open(yaml_path, "r", encoding="utf-8") as f:
        data = yaml.safe_load(f)
    blocks = data["blocks"]
    prompt = (
        "You are given a list of UI blocks, each with a Markdown snippet. "
        "For each block, return a YAML list with these fields for each block:\n"
        "- type: a single, short, lowercase, one-word name for the block (like 'cards', 'images', 'heading')\n"
        "- description: a single, unique, one-line description of the block\n"
        "- html_description: For this field, use the following instructions to generate the value from the Markdown (not HTML):\n"
        "Analyze the provided Markdown content to identify its core structural components (e.g., headers, lists, code blocks, tables, images, or custom HTML elements like accordions/details). For each identified component, disregard any specific textual or image data, and focus solely on its arrangement, hierarchy, and any inherent structural attributes (like heading levels, list types, table column counts, alignments, or the presence of embedded HTML elements and their basic attributes like `src`, `alt`, `border`, `width`, `summary`, etc.). Pay particular attention to table row counts and the presence of Markdown separator lines.\n\nThen, generate a detailed, clear, and unambiguous prompt. This generated prompt, when given to another LLM, should produce a corresponding empty HTML representation that strictly adheres to the structural layout, element types, and inherent attributes of the original Markdown.\n\n**The prompt you generate must guide the target LLM to:**\n\n1.  **Map Markdown to Empty HTML Elements:** Translate standard Markdown elements (e.g., `#` to `<h1>`, `*` to `<ul>`/`<li>`, `|` to `<table>`/`<th>`/`<td>`, `![ ]( )` to `<img>`, `[ ]( )` to `<a href=\"\">`, etc.) into their respective empty HTML tags.\n2.  **Preserve Structure & Attributes:**\n    * For tables: Maintain the exact column count, apply `style=\"text-align:...\"` to `<th>` and `<td>` elements based on Markdown's column alignment indicators. Ensure the correct number of `<tr>` elements for data rows is included, and translate Markdown separator rows (`|---|`) into an appropriate empty HTML `<tr>` structure (e.g., `<td colspan=\"N\" style=\"border-top: 1px solid #ccc;\"></td>`).\n    * For images (`<img>`) and links (`<a href=\"\">`): Include `src=\"\"`, `alt=\"\"`, `href=\"\"`, `title=\"\"` attributes with empty string values. Preserve `width`, `height`, `border` attributes if explicitly present in original Markdown's raw HTML image syntax.\n    * For any embedded raw HTML (e.g., `<details>`, `<summary>`, `<div>`, `<span>`): Preserve the exact tags and all their original attributes (including their values and order).\n3.  **Ensure Strict Emptiness:** All generated HTML elements must be empty of content (e.g., `<p></p>`, `<li></li>`, `<th></th>`, `<td></td>`). Attribute values should be empty strings (`\"\"`) unless a specific value was present in original raw HTML and needs to be preserved (as per point 2).\n4.  **Enforce HTML Output Format:** The final output from the target LLM must be valid, well-formed, and properly indented HTML5. It should *only* contain the structural HTML, with no conversational text, explanatory notes, comments, or surrounding document structure like `<!DOCTYPE html>`, `<html>`, `<head>`, `<body>` tags.\n\n**Output only the generated prompt text, nothing else.**\n"
        "All YAML string values must be double-quoted.\n"
        "Do not include any 'id' or 'name' fields. Output ONLY valid YAML. Do NOT output HTML, markdown, or any code blocks. Do NOT use <p> tags or any HTML except for the html_description field. If you cannot answer, return an empty YAML list: []\n\n"
        "Blocks:\n"
    )
    for i, block in enumerate(blocks, 1):
        prompt += f"- block_{i}:\n"
        prompt += f"    markdown: |\n"
        for line in block.get("markdown", "").splitlines():
            prompt += f"      {line}\n"

    # call Gemini via streaming
    contents = [
        types.Content(
            role="user",
            parts=[types.Part.from_text(text=prompt)]
        )
    ]
    config = types.GenerateContentConfig(
        thinking_config=types.ThinkingConfig(thinking_budget=0),
        response_mime_type="text/plain",
    )
    stream = client.models.generate_content_stream(
        model="gemini-1.5-pro-latest",
        contents=contents,
        config=config
    )
    raw = ""
    for chunk in stream:
        if hasattr(chunk, "text"):
            raw += chunk.text
    llm_yaml = raw.strip()

    print("LLM response full output:\n", llm_yaml)
    if not llm_yaml:
        print("Warning: LLM response is empty. No enrichment applied.")
        return

    # Remove code fences if present
    llm_yaml = re.sub(r"^```(?:yaml)?", "", llm_yaml, flags=re.MULTILINE).replace("```", "").strip()
    # If the response starts with a list item, treat as a list
    if llm_yaml.startswith('- '):
        try:
            enriched_blocks = yaml.safe_load(llm_yaml)
            if not isinstance(enriched_blocks, list):
                print("Warning: LLM response is not a YAML list. Skipping enrichment.")
                return
            # Merge description/html_description into blocks
            for i, block in enumerate(blocks):
                if i < len(enriched_blocks):
                    for key in ['description', 'html_description']:
                        if key in enriched_blocks[i]:
                            block[key] = enriched_blocks[i][key]
            # Save with improved YAML formatter
            with open(yaml_path, "w", encoding="utf-8") as f:
                yaml.dump(data, f,
                         Dumper=BlockDumper,
                         allow_unicode=True,
                         sort_keys=False,
                         default_flow_style=False,
                         indent=2,
                         width=120)

            print("block_kb.yaml has been enriched with LLM descriptions.")
            return
        except Exception as e:
            print("Failed to parse LLM YAML list:", e)
            print("Raw response was:\n", llm_yaml[:1000])
            return

    # Extract YAML from code block if present
    codeblock_match = re.search(r"```(?:yaml)?\s*([\s\S]*?)\s*```", llm_yaml, re.IGNORECASE)
    if (codeblock_match):
        llm_yaml = codeblock_match.group(1).strip()
    # Remove indented code blocks
    llm_yaml = re.sub(r"(^|\n)(    |\t).*(\n|$)", "\n", llm_yaml)
    llm_yaml = llm_yaml.strip()
    # Quote unquoted YAML values with colon
    def quote_colon_values(yaml_text):
        def replacer(match):
            key = match.group(1)
            value = match.group(2)
            if value.startswith('"') and value.endswith('"'):
                return match.group(0)
            return f'{key}: "{value}"'
        return re.sub(r'^(\s*\w+:) ([^"\n]*:[^\n"]*)$', replacer, yaml_text, flags=re.MULTILINE)
    llm_yaml = quote_colon_values(llm_yaml)
    # Find YAML list or dict
    yaml_to_parse = None
    if llm_yaml.startswith('blocks:'):
        yaml_to_parse = llm_yaml
    elif llm_yaml.startswith('- type:'):
        yaml_to_parse = f"blocks:\n{llm_yaml}"
    else:
        idx_blocks = llm_yaml.find('blocks:')
        idx_type = llm_yaml.find('- type:')
        if idx_blocks != -1:
            yaml_to_parse = llm_yaml[idx_blocks:]
        elif idx_type != -1:
            yaml_to_parse = f"blocks:\n{llm_yaml[idx_type:]}"
        else:
            print("Warning: Could not find YAML list or dict in LLM response. Skipping enrichment.")
            print("LLM response preview:", llm_yaml[:1000])
            return
    print("YAML to be parsed preview:", yaml_to_parse[:500])
    try:
        parsed = yaml.safe_load(yaml_to_parse)
        enriched_blocks = parsed["blocks"] if isinstance(parsed, dict) and "blocks" in parsed else parsed
        if isinstance(enriched_blocks, dict):
            enriched_blocks = list(enriched_blocks.values())
        if not enriched_blocks or not isinstance(enriched_blocks, list):
            print("Warning: LLM response could not be parsed into blocks. No enrichment applied.")
            return
        for i, orig_block in enumerate(blocks):
            if i < len(enriched_blocks):
                enriched = enriched_blocks[i]
                for key in ['type', 'description', 'html_description']:
                    if key in enriched:
                        orig_block[key] = enriched[key]
            if 'html_description' not in orig_block or not orig_block['html_description']:
                orig_block['html_description'] = 'No graphical HTML description generated.'
        data["blocks"] = blocks
        # Save with improved YAML formatter
        with open(yaml_path, "w", encoding="utf-8") as f:
            yaml.dump(data, f,
                     Dumper=BlockDumper,
                     allow_unicode=True,
                     sort_keys=False,
                     default_flow_style=False,
                     indent=2,
                     width=120)

        print("block_kb.yaml has been batch-enriched in a single LLM call, with html_description for each block.")
    except Exception as e:
        print("Failed to parse LLM response:", e)
        print("Raw response was:\n", yaml_to_parse if yaml_to_parse else llm_yaml[:1000])

# --- MAIN ORCHESTRATION ---
def main():
    endpoint_list = get_list_of_urls(BASE_URL, JSON_LIST_URL)
    if not endpoint_list:
        exit(1)
    combined_md_path = os.path.join(MD_DIR, "input_all_md.md")
    download_all_markdowns(endpoint_list, BASE_URL, combined_md_path)
    split_components(combined_md_path, MD_DIR)
    os.remove(combined_md_path)
    build_yaml(MD_DIR, HTML_DIR, OUTPUT_YAML)
    enrich_yaml_with_llm(OUTPUT_YAML)

if __name__ == "__main__":
    main()
