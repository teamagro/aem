import logging
from fastapi import FastAPI, Depends, File, UploadFile, HTTPException
from typing import List, Optional, Any
# from PIL import Image
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles

from app.api.v1.routers import router, read_project_images, PageCreate
from app.api.v1.chat_routers import chat_router
from app.core.config import settings
from app.core.logging import setup_logging
from app.db.session import SessionLocal, engine
from app.db.init_db import init_db

from dotenv import load_dotenv
import os
from sqlalchemy.orm import sessionmaker


from app.services.upload_service import *

# --- Image Captioning Module Imports ---
from app.services import captioning_service # Import the new service


load_dotenv()
# Setup logging
setup_logging()
logger = logging.getLogger(__name__)

app = FastAPI(
    title=settings.PROJECT_NAME,
    description="Enterprise Project Management System API with Image Captioning",
    version="1.1.0",
    openapi_url=f"{settings.API_V1_STR}/openapi.json",
)


# Set up CORS
if settings.CORS_ORIGINS:
    app.add_middleware(
        CORSMiddleware,
        allow_origins=["*"],
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
    )

# Include API routers
app.include_router(router, prefix=settings.API_V1_STR)
app.include_router(chat_router, prefix="")

# Serve static files (uploaded images)
app.mount("/static", StaticFiles(directory="static"), name="static")


@app.on_event("startup")
async def on_startup():
    """Initialize database and perform any startup tasks"""
    db = SessionLocal()
    init_db(db)
    db.close()
    # Initialize the Hugging Face image captioning model via the service
    await captioning_service.init_captioning_model()

Session = sessionmaker(bind=engine)
session = Session()


@app.get("/")
async def root():
    return {
        "message": "Welcome to the  System API",
        "docs": "/docs",
        "redoc": "/redoc",
    }
