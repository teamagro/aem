from fastapi import FastAPI, APIRouter,UploadFile, HTTPException,File,Depends
import os

#import all service functions
from app.services.chat_service import analyze_image, load_block_kb, map_ui_to_blocks, generate_docs


#import all schemas
from app.schemas.analysis import AnalysisMetadata
from app.schemas.chat_schemas import AnalyzeImage,MappingData,GenerateDocs

from app.models.image import Image
from app.models.page import Page
from app.models.project import Project
from app.schemas.project import ProjectInDB
from app.services.image_service import ImageService
from app.services.image_processing import ImageProcessingService

from app.api.v1.routers import router, read_project_images, PageCreate

from app.db.session import SessionLocal, engine
from app.db.init_db import init_db
from sqlalchemy.orm import sessionmaker
from sqlalchemy.orm import Session
from app.db.deps import get_db
from pathlib import Path # Added for Path operations







# --- Image Captioning Module Imports ---
from app.services import captioning_service # Import the new service
from app.schemas.captioning_schemas import ImageCaptionRequest, CaptionSummaryResponse # Import schemas


from app.services.upload_service import *

import asyncio
import json

static_dir = Path('static')


from app.db.session import SessionLocal, engine
from app.crud.image import create_image, get_images_by_project
from app.crud.project import get_project

Session_create = sessionmaker(bind=engine)
session_bind = Session()



chat_router = APIRouter()


@chat_router.get('/api/v1/kb-metadata')
async def get_kb_data():
    try:
        # Load the block knowledge base
        block_kb = load_block_kb()
        global_count = 0
        page_building_count = 0

        # Iterate through the blocks and count based on the 'element' field
        for block in block_kb:
            if block_kb[block]['element'] == 'global':
                global_count += 1
            elif block_kb[block]['element'] == 'page building':
                page_building_count += 1
        return {'brand': 'AEM','total_count': global_count+page_building_count,'global_count': global_count, 'page_building_count': page_building_count}
    except Exception as e:
        raise e


@chat_router.post("/upload-image")
async def upload_image(file:UploadFile = File(...)):
    try:
        img_content = await file.read()
        img_path = os.path.join('static','images',file.filename)
        with open(img_path,"wb") as f:
            while contents := await file.read(1024):
                f.write(contents)
    except Exception as e:
        raise e
    return {"filename":file.filename, "detail":"Image Uploaded"}

# Analyse image response from LLM and return metadata
def analyze_image_resp(process_data, no_of_images):
    image_count = 0
    link_count = 0
    block_count = 0
    form_count = 0
    video_count = 0
    processingData = {}
    processingData['llm_response'] = process_data
    processingData['pages'] = len(process_data)
    
    # Iterate through pages and components
    for page in process_data:
        # Check if page has components key
        if not isinstance(page, dict):
            print(f"WARNING: Skipping non-dict page: {type(page)}")
            continue
            
        if "components" not in page:
            print(f"WARNING: Skipping page without 'components' key. Keys: {list(page.keys())}")
            continue
            
        if not isinstance(page["components"], list):
            print(f"WARNING: 'components' is not a list: {type(page['components'])}")
            continue
            
        for component in page["components"]:
            if not isinstance(component, dict):
                print(f"WARNING: Skipping non-dict component: {type(component)}")
                continue
                
            # Count component types
            if component.get("type"):
                block_count += 1
                
            # Count images
            if "properties" in component:
                if "imageRef" in component["properties"] and component["properties"]["imageRef"]:
                    image_count += 1
                if "items" in component["properties"]:
                    for item in component["properties"]["items"]:
                        if "imageRef" in item and item["imageRef"]:
                            image_count += 1

            # Count links
            if "properties" in component:
                if "navigation_links" in component["properties"]:
                    link_count += len(component["properties"]["navigation_links"])
                if "utility_icons" in component["properties"]:
                    link_count += len(component["properties"]["utility_icons"])
                if "items" in component["properties"]:
                    for item in component["properties"]["items"]:
                        if "link_url" in item or "link" in item:
                            link_count += 1
                if "cta_button" in component["properties"] and "url" in component["properties"]["cta_button"]:
                    link_count += 1
            
            # Count forms
            if "properties" in component:
                if "forms" in component["properties"]:
                    form_count += len(component["properties"]["forms"])

            # Count videos
            if "properties" in component:
                if "videos" in component["properties"]:
                    video_count += len(component["properties"]["videos"])

    processingData['blocks'] = block_count
    processingData['images'] = image_count
    processingData['links'] = link_count
    processingData['forms'] = form_count
    processingData['videos'] = video_count
    progress_percentage = (processingData['pages'] / no_of_images) * 100 if no_of_images > 0 else 0
    processingData['progress'] = f"{processingData['pages']}/{no_of_images} ({progress_percentage:.2f}%)"
    
    return processingData

@chat_router.post("/api/v1/analyze")
async def analyze(data:AnalyzeImage):
    db = SessionLocal()
    service = ImageProcessingService(db)
    try:
        # Use the local db session consistently
        try:
            projectImages = read_project_images(project_id=data.project_id, db=db)
            
            # If no images found, return early
            if not projectImages:
                print(f"No images found for project {data.project_id}")
                return {"error": "No images found for this project", "results": []}
                
        except Exception as project_err:
            print(f"Error retrieving project images: {str(project_err)}")
            return {"error": f"Error retrieving project images: {str(project_err)}", "results": []}

        # Define a coroutine to process each image
        async def process_image(indivProject):
            try:
                # First check if we already have processed results
                if (indivProject.llm_response is not None) and (indivProject.llm_processed is True):
                    try:
                        return json.loads(indivProject.llm_response)
                    except json.decoder.JSONDecodeError as json_err:
                        print(f"Error parsing stored JSON for image {indivProject.filepath}: {str(json_err)}")
                        # Continue with reprocessing the image if stored JSON is invalid
                
                # Generate captions for the image
                try:
                    caption_data = await create_captions_for_images_in_folder_endpoint(
                        ImageCaptionRequest(folder_location='assets')
                    )
                    
                    # Validate caption data structure
                    if not isinstance(caption_data, dict) and hasattr(caption_data, '__dict__'):
                        # It's an object with attributes, convert to dict
                        print(f"Converting caption_data object to dictionary")
                        if hasattr(caption_data, 'captions') and caption_data.captions:
                            caption_data = {"captions": caption_data.captions}
                        else:
                            caption_data = {"captions": {}}
                    elif not isinstance(caption_data, dict):
                        print(f"Caption data is not a dict, got {type(caption_data)}")
                        caption_data = {"captions": {}}
                except Exception as caption_err:
                    print(f"Error generating captions: {str(caption_err)}")
                    caption_data = {"captions": {}}  # Provide empty captions if generation fails
                
                # Analyze the image with Gemini AI
                print(f"Analyzing image: {indivProject.filepath}")
                image_data = analyze_image(image_path=indivProject.filepath, captions=caption_data)
                
                # Store the results in database
                image_id = indivProject.id
                try:
                    await service.mark_as_processed(
                        image_id=image_id,
                        llm_response=image_data,
                        success=True
                    )
                except Exception as db_err:
                    print(f"Error saving analysis results to database: {str(db_err)}")
                    # Continue even if saving to DB fails
                    
                return image_data
            except Exception as e:
                print(f"Error processing image {indivProject.filepath}: {str(e)}")
                # Return a fallback response instead of failing the whole batch
                return {
                    "page_title": "Error Processing Image",
                    "components": [
                        {
                            "type": "error", 
                            "properties": {
                                "title": "Image Processing Error",
                                "description": f"Failed to process image: {str(e)}"
                            },
                            "layout": "full-width",
                            "element_type": "page-building"
                        }
                    ]
                }

        # Run all image processing tasks in parallel
        try:
            print(f"Starting parallel processing of {len(projectImages)} images...")
            # Process each image individually and collect results
            image_results = []
            for i, indivProject in enumerate(projectImages):
                try:
                    print(f"Processing image {i+1}/{len(projectImages)}: {indivProject.filepath}")
                    result = await process_image(indivProject)
                    
                    # Validate that the result has the expected structure
                    if not isinstance(result, dict):
                        print(f"WARNING: Image {indivProject.filepath} returned non-dict result: {type(result)}")
                    elif "components" not in result:
                        print(f"WARNING: Image {indivProject.filepath} missing 'components' key in result")
                        print(f"Result keys: {list(result.keys())}")
                    
                    image_results.append(result)
                    print(f"Successfully processed image {i+1}: {indivProject.filepath}")
                except Exception as individual_err:
                    print(f"Error processing individual image {indivProject.filepath}: {str(individual_err)}")
                    # Add a fallback response for this specific image
                    image_results.append({
                        "page_title": f"Error Processing Image {i+1}",
                        "components": [
                            {
                                "type": "error",
                                "properties": {
                                    "title": "Image Processing Error",
                                    "description": f"Failed to process image: {str(individual_err)}"
                                },
                                "layout": "full-width",
                                "element_type": "page-building"
                            }
                        ]
                    })
            
            print(f"Completed processing {len(image_results)} images")
            return analyze_image_resp(image_results, no_of_images=len(projectImages))
        except Exception as gather_err:
            print(f"Error during parallel image processing: {str(gather_err)}")
            # Return a fallback response with error information
            return {
                "error": f"Error during image analysis: {str(gather_err)}",
                "results": [],
                "no_of_images": len(projectImages),
                "success": False
            }
    except Exception as e:
        print(f"Unhandled exception in analyze endpoint: {str(e)}")
        # Return a structured error response rather than re-raising
        return {
            "error": f"Unhandled exception: {str(e)}",
            "results": [],
            "success": False
        }
    finally:
        # Always close your db session
        db.close()


@chat_router.post("/api/v1/mapping")
async def mapping(data:MappingData):
    try:
        #pass response value of (llm_response) in 
        # components_data param 

        #response body
    #     {
    #     "page_title" :strt,
    #     "mapped_data" : list,
    #     "not_found_block":int,
    #     "global_block_number" :int,
    #     "block_used" : int

    # }
        #return list of dict
        all_pages_mapped_data =  []
        for page in data.components_data:
            block_data = await map_ui_to_blocks(page_json=page, block_kb=load_block_kb())
            all_pages_mapped_data.append(block_data)
        return all_pages_mapped_data
    except Exception as e:
        raise e

@chat_router.post("/api/v1/generate-doc")
async def generate(project_id:int, db: Session = Depends(get_db)):
    #return google docs link
    try:
        #pass mapping api response in this mapped_data list to mapped_data
        #get data from database by project_id
        mapped_data = []
        get_project_name = get_project(db,project_id)
        project_name = get_project_name.project_name
        images = get_images_by_project(db, project_id=project_id)
        for image in images:
            analyze_data = json.loads(image.llm_response)
            block_data = await map_ui_to_blocks(page_json=analyze_data, block_kb=load_block_kb())
            mapped_data.append(block_data)  

        page_output_data={}
        google_docs_folder_created = False
        folder_id = ""
        page_data_return = {}
        global_header_list= []
        for map_data in mapped_data:
            try:
                data_final_page_wise,global_header_list = await generate_docs(mapped=map_data["mapped_data"], project_name=project_name,global_header_list=global_header_list)
                
                if not google_docs_folder_created:
                    print(f"Creating folder for project: {project_name}")
                    upload_folder_links = await create_folder_api(project_name)
                    print(f"Folder creation response: {upload_folder_links}")
                    
                    if "error" in upload_folder_links:
                        print(f"Warning: Error in folder creation: {upload_folder_links['error']}")
                    
                    # Safely get folder IDs with fallbacks
                    folder_id = upload_folder_links.get("folder_id", "default_folder_id")
                    folder_url = upload_folder_links.get("folder_url", "#")
                    global_folder_id = upload_folder_links.get("global_folder_id", "default_global_folder_id")
                    google_docs_folder_created = True
                
                print(f"Processing output data: {data_final_page_wise}")
            except Exception as map_err:
                print(f"Error processing mapped data: {str(map_err)}")
                
        # Upload everything to google drive
        project_path = os.path.join("output",project_name)
        global_path = os.path.join(project_path,"global")
        
        # Verify directories exist
        if not os.path.exists(project_path):
            print(f"Warning: Project path does not exist: {project_path}")
            os.makedirs(project_path, exist_ok=True)
            
        if not os.path.exists(global_path):
            print(f"Warning: Global path does not exist: {global_path}")
            os.makedirs(global_path, exist_ok=True)
 
        page_data_return = {}
        global_pages=[]
        
        # Process main project files
        try:
            print(f"Processing files in directory: {project_path}")
            for file_name in os.listdir(project_path):   
                full_path = os.path.join(project_path,file_name)
                if not os.path.isdir(full_path):
                    try:
                        print(f"Uploading file: {full_path}")
                        file_upload_url = await upload_file_to_drive(full_path, folder_id)
                        print(f"Upload response: {file_upload_url}")
                        
                        page_data_return[file_name] = {
                            "name": file_name,
                            "type": file_name.split(".")[1],
                            "nodeType": 'file',
                            "url": file_upload_url.get("file_url", "#")
                        }
                    except Exception as file_err:
                        print(f"Error uploading file {full_path}: {str(file_err)}")
                        page_data_return[file_name] = {
                            "name": file_name,
                            "type": file_name.split(".")[1],
                            "nodeType": 'file',
                            "url": "#",
                            "error": str(file_err)
                        }
        except Exception as dir_err:
            print(f"Error processing project directory: {str(dir_err)}")
                
        # Process global files
        try:
            print(f"Processing files in global directory: {global_path}")
            for file_name in os.listdir(global_path):  
                full_path = os.path.join(global_path, file_name)
                if not os.path.isdir(full_path):
                    try:  
                        path = await upload_file_to_drive(full_path, global_folder_id)
                        global_pages.append({
                            "name": file_name,
                            "type": file_name.split(".")[1],
                            "nodeType": 'file',
                            "url": "#",
                            "url": path.get("file_url", "#")
                        })
                    except Exception as global_file_err:
                        print(f"Error uploading global file {full_path}: {str(global_file_err)}")
                        global_pages.append(f"Error with {file_name}: {str(global_file_err)}")
        except Exception as global_dir_err:
            print(f"Error processing global directory: {str(global_dir_err)}")
            global_pages.append("Error loading global files")

        page_data_return["global"]={
                    "name": "global",
                    "type": 'folder',
                    "nodeType": 'folder',
                    "children": global_pages
                }

        return_json = {
            "documents": {
                "name": "documents",
                "type": "folder",
                "nodeType": "folder",
            }
            }
        return_json["documents"]["children"] = page_data_return
        return return_json
    except Exception as e:
        print(f"Error in generate-doc endpoint: {str(e)}")
        # Return a minimal valid response that the frontend can handle
        return {
            "documents": {
                "name": "documents",
                "type": "folder",
                "nodeType": "folder",
                "children": {
                    "error": {
                        "name": "Error",
                        "type": "file",
                        "nodeType": "file",
                        "url": "#",
                        "error_details": str(e)
                    }
                },
                "error": str(e)
            }
        }



@chat_router.post("/create-folder")
async def create_folder(project_name: str = Form(...)):
    """Handles API request to create a Google Drive folder, 'Global' subfolder, and trigger GitHub workflow"""
    return await create_folder_api(project_name)
    


@chat_router.post("/upload-folder")
async def upload_folder(local_path: str = Form(...), folder_id:str = Form(...)):
    """Uploads all files from a local folder into the most recently created Google Drive folder."""
    return {"uploaded_files": await upload_folder_to_drive(local_path,folder_id)}



@chat_router.post("/upload-folder-with-dymamic-folder-id")
def upload_folder(local_path: str = Form(...), folder_id: str = Form(...)):
    """Uploads all files from a local folder into the specified Google Drive folder."""
    return {"uploaded_files": upload_folder_to_drive_with_dynamic_folder_id(local_path, folder_id)}

@chat_router.post("/upload-file-with-dymamic-folder-id")
async def upload_file(local_path: str = Form(...), folder_id: str = Form(...)):
    """Uploads a file from local system to the Google Drive folder and converts it"""
    return await upload_file_to_drive(local_path, folder_id)


@chat_router.get("/fetch-files")
def fetch_files():
    """Fetches all files and folders recursively from the latest created Google Drive folder."""    
    return {"files_in_folder": fetch_files_recursively()}



@chat_router.get("/fetch-github-files")
def fetch_github_files():
    """Fetches all files and folders from the latest created GitHub branch."""    
    return fetch_github_branch_files()

@chat_router.post('/api/analysis-metadata')
async def create_metadata(data:AnalysisMetadata):
    # return data
    try:
        meta = session_bind.query(Project).filter(Project.id == data).first()
        return meta
    except Exception as e:
        raise e


# --- Image Captioning Endpoint ---
@chat_router.post("/caption-images/", response_model=CaptionSummaryResponse)
async def create_captions_for_images_in_folder_endpoint(request: ImageCaptionRequest):
    """
    FastAPI endpoint to process images in a given folder (relative to static root) and generate captions.
    Returns a dictionary with captions that can be used by the analyze_image function.
    """
    # logger.info(f"Received request to caption images in folder: {request.folder_location}")
    # The folder_location is expected to be relative to the 'static_dir'
    # e.g., if static_dir is '/app/static' and request.folder_location is 'project_images/run1',
    # then the service will look in '/app/static/project_images/run1'.
    try:
        response = await captioning_service.generate_captions_for_images_in_folder(
            folder_path_relative=request.folder_location,
            base_static_path_abs=str(static_dir.resolve()) # Pass absolute path of static_dir
        )
        
        # Convert the Pydantic model to a plain dictionary for better compatibility
        if hasattr(response, 'to_dict') and callable(getattr(response, 'to_dict')):
            return response.to_dict()
        elif hasattr(response, 'dict') and callable(getattr(response, 'dict')):
            return response.dict()
        elif hasattr(response, 'model_dump') and callable(getattr(response, 'model_dump')):
            return response.model_dump()
        else:
            print(f"Warning: Could not convert response to dict. Type: {type(response)}")
            return {"captions": {}}
            
    except HTTPException as http_exc: # Re-raise HTTPExceptions from the service
        raise http_exc
    except Exception as e: # Catch any other unexpected errors
        print(f"Error in caption endpoint for folder '{request.folder_location}': {str(e)}")
        return {"captions": {}}

