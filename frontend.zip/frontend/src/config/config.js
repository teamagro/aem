const config = {
  API_BASE_URL: process.env.API_BASE_URL || 'http://backend-container:8000/api/v1',
  UPLOAD_BASE_DIR: '/uploads/',  // Base directory for uploads
  MAX_UPLOAD_SIZE: 10 * 1024 * 1024, // 10MB max upload size
};

export default config;