import apiClient, { api, loadingTracker } from '../utils/apiClient';
import config from '../config/config';

// Track active requests with progress
const activeRequests = new Map();
const metadataRequests = new Map();

/**
 * Enhanced ApiService without global loading overlay
 */
const ApiService = {
  /**
   * Get all projects
   * 
   * @returns {Promise} Promise with projects data
   */
  async getAllProjects() {
    try {
      return await apiClient.withRetry(
        async () => {
          const response = await api.get('/projects/');
          return response.data;
        },
        {
          onRetry: (retryCount, maxRetries, delay) => {
            console.log(`Retrying project fetch (${retryCount}/${maxRetries}) after ${delay}ms...`);
          }
        }
      );
    } catch (error) {
      this._handleError(error, 'Failed to load projects');
    }
  },

  /**
   * Create a new project
   * 
   * @param {Object} projectData - Project data to create
   * @returns {Promise} Promise with created project
   */
  async createProject(projectData) {
    try {
      return await apiClient.withRetry(
        async () => {
          const response = await api.post('/projects/', projectData);
          return response.data;
        },
        {
          // Create project is a critical operation, retry with caution
          maxRetries: 3,
          onRetry: (retryCount, maxRetries, delay) => {
            console.log(`Retrying project creation (${retryCount}/${maxRetries}) after ${delay}ms...`);
          }
        }
      );
    } catch (error) {
      this._handleError(error, 'Failed to create project');
    }
  },

  /**
   * Upload a file for a project
   * 
   * @param {string} projectId - Project ID
   * @param {File} file - File to upload
   * @returns {Promise} Promise with upload result
   */
  async uploadProjectFile(projectId, file) {
    // Validate file size
    if (file.size > config.MAX_UPLOAD_SIZE) {
      throw new Error(`File size exceeds maximum allowed size of ${config.MAX_UPLOAD_SIZE / (1024 * 1024)}MB`);
    }
    
    try {
      const formData = new FormData();
      formData.append('file', file);
      
      // For file uploads, custom retry logic
      return await apiClient.withRetry(
        async () => {
          const response = await api.post(
            `/projects/${projectId}/images/`,  // Fixed endpoint URL to match original ApiService
            formData,
            {
              headers: {
                'Content-Type': 'multipart/form-data'
              },
              onUploadProgress: progressEvent => {
                // Calculate and report upload progress
                const percentCompleted = Math.round((progressEvent.loaded * 100) / progressEvent.total);
                console.log(`Upload progress: ${percentCompleted}%`);
                
                // Store the progress for this request
                this._updateRequestProgress(projectId, percentCompleted);
              }
            }
          );
          return response.data;
        },
        {
          // For file uploads, be more cautious with retries - only retry on server errors
          maxRetries: 2,
          shouldRetry: (error) => error?.response?.status >= 500,
          onRetry: (retryCount, maxRetries, delay) => {
            console.log(`Retrying file upload (${retryCount}/${maxRetries}) after ${delay}ms...`);
            // Report upload retry to user
            this._updateRequestProgress(projectId, `Retrying upload (${retryCount}/${maxRetries})...`);
          }
        }
      );
    } catch (error) {
      this._handleError(error, 'Failed to upload file');
    }
  },

  /**
   * Get project details
   * 
   * @param {string} projectId - Project ID
   * @returns {Promise} Promise with project details
   */
  async getProjectDetails(projectId) {
    try {
      return await apiClient.withRetry(
        async () => {
          const response = await api.get(`/projects/${projectId}/`);
          return response.data;
        },
        {
          onRetry: (retryCount, maxRetries, delay) => {
            console.log(`Retrying project details fetch (${retryCount}/${maxRetries}) after ${delay}ms...`);
          }
        }
      );
    } catch (error) {
      this._handleError(error, 'Failed to load project details');
    }
  },

  /**
   * Get project images
   * 
   * @param {string} projectId - Project ID
   * @returns {Promise} Promise with project images
   */
  async getProjectImages(projectId) {
    try {
      const response = await api.get(`/projects/${projectId}/images/`);
      return response.data;
    } catch (error) {
      this._handleError(error, 'Failed to load project images');
    }
  },

  /**
   * Get project analysis
   * 
   * @param {string} projectId - Project ID
   * @returns {Promise} Promise with project analysis
   */
  async getProjectAnalysis(projectId) {
    try {
      const response = await api.get(`/projects/${projectId}/analysis`);
      return response.data;
    } catch (error) {
      this._handleError(error, 'Failed to load project analysis');
    }
  },

  /**
   * Get metadata
   * 
   * @param {string} projectId - Project name
   * @returns {Promise} Promise with metadata
   */
  async getMetadata(projectId) {
    if (metadataRequests.has(projectId)) {
      // Return the existing promise if a request is already in progress
      return metadataRequests.get(projectId);
    }
    const promise = (async () => {
      try {
        const response = await api.post('/analyze', { project_id: projectId });
        return response.data;
      } finally {
        metadataRequests.delete(projectId);
      }
    })();
    metadataRequests.set(projectId, promise);
    return promise;
  },

  /**
   * Get KB metadata
   * 
   * @returns {Promise} Promise with KB metadata
   */
  async getKBMetadata() {
    try {
      const response = await api.get('/kb-metadata');
      return response.data;
    } catch (error) {
      this._handleError(error, 'Failed to load knowledge base metadata');
    }
  },

  /**
   * Get templates
   * 
   * @param {string} templateType - Optional template type filter
   * @returns {Promise} Promise with templates data
   */
  async getTemplates(templateType = null) {
    try {
      const params = templateType ? { template_type: templateType } : {};
      const response = await api.get('/aem-templates/', { params });
      return response.data;
    } catch (error) {
      this._handleError(error, 'Failed to load templates');
    }
  },

  /**
   * Post llmResponse to mapping API
   * 
   * @param {string} projectId - Project ID
   * @param {Object} llmData - LLM response data to send to mapping API
   * @returns {Promise} Promise with mapping result
   */
  async postMappingData(projectId, llmData) {
    try {
      return await apiClient.withRetry(
        async () => {
          const response = await api.post('/mapping', {
            project_id: projectId,
            components_data: llmData
          });
          return response.data;
        },
        {
          maxRetries: 3,
          onRetry: (retryCount, maxRetries, delay) => {
            console.log(`Retrying mapping data submission (${retryCount}/${maxRetries}) after ${delay}ms...`);
          }
        }
      );
    } catch (error) {
      this._handleError(error, 'Failed to post mapping data');
    }
  },

  /**
   * Generate documentation for a project
   * 
   * @param {string} projectId - Project ID
   * @returns {Promise} Promise with generated documentation data
   */
  async generateDocumentation(projectId) {
    try {
      return await apiClient.withRetry(
        async () => {
          const response = await api.post(`/generate-doc?project_id=${projectId}`);
          return response.data;
        },
        {
          maxRetries: 3,
          onRetry: (retryCount, maxRetries, delay) => {
            console.log(`Retrying documentation generation (${retryCount}/${maxRetries}) after ${delay}ms...`);
          }
        }
      );
    } catch (error) {
      this._handleError(error, 'Failed to generate documentation');
    }
  },

  /**
   * Check if a request is in progress
   * 
   * @param {string} requestId - Unique request identifier
   * @returns {boolean} Whether request is in progress
   */
  isRequestInProgress(requestId) {
    return activeRequests.has(requestId);
  },

  /**
   * Get request progress
   * 
   * @param {string} requestId - Unique request identifier
   * @returns {number} Progress percentage
   */
  getRequestProgress(requestId) {
    return activeRequests.get(requestId)?.progress || 0;
  },

  /**
   * Cancel a request
   * 
   * @param {string} requestId - Unique request identifier
   */
  cancelRequest(requestId) {
    const requestInfo = activeRequests.get(requestId);
    if (requestInfo && requestInfo.cancelToken) {
      requestInfo.cancelToken.cancel('Request canceled by user');
    }
    activeRequests.delete(requestId);
  },

  /**
   * Update request progress
   * 
   * @param {string} requestId - Unique request identifier
   * @param {number} progress - Progress percentage
   * @private
   */
  _updateRequestProgress(requestId, progress) {
    const requestInfo = activeRequests.get(requestId) || {};
    activeRequests.set(requestId, { 
      ...requestInfo, 
      progress 
    });
  },

  /**
   * Handle API error
   * 
   * @param {Error} error - Error object
   * @param {string} defaultMessage - Default error message
   * @private
   */
  _handleError(error, defaultMessage = 'An error occurred') {
    console.error(`API Error: ${defaultMessage}`, error);
    
    if (error.response) {
      // Server responded with non-2xx status
      const message = error.response.data?.detail || defaultMessage;
      throw new Error(message);
    } else if (error.request) {
      // Request made but no response received
      throw new Error('Network error. Please check your connection and try again.');
    } else {
      // Something else happened while setting up the request
      throw error;
    }
  }
};

export default ApiService;
