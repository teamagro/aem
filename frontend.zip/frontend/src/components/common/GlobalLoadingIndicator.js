import React, { useEffect } from 'react';
import styled, { keyframes } from 'styled-components';
import { useLocation } from 'react-router-dom';
import useApiLoading from '../../hooks/useApiLoading';
import apiClient from '../../utils/apiClient';

// Progress bar animation
const progressAnimation = keyframes`
  0% { width: 0%; }
  50% { width: 70%; }
  100% { width: 100%; }
`;

const LoadingProgressContainer = styled.div`
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  height: 3px;
  z-index: 9999;
  background-color: transparent;
  pointer-events: none;
`;

const LoadingProgressBar = styled.div`
  height: 100%;
  background-color: ${props => props.theme.colors?.primary || '#4a7dfc'};
  width: 0;
  animation: ${progressAnimation} ${props => props.speed || '3s'} ease-in-out infinite;
  opacity: ${props => props.show ? 1 : 0};
  transition: opacity 0.3s ease;
`;

/**
 * Global loading indicator that appears at top of screen
 * Shows a subtle progress bar for background operations
 * Automatically cleans up loading states on route changes
 */
const GlobalLoadingIndicator = ({ minimum = 700 }) => {
  // Track all API requests
  const { activeCount, isLoading } = useApiLoading();
  const location = useLocation();
  
  // Clear loading indicators when route changes
  useEffect(() => {
    // This will clear all active loading indicators when navigation occurs
    apiClient.loading.clearAll();
  }, [location]);
  
  return (
    <LoadingProgressContainer>
      <LoadingProgressBar 
        show={activeCount > 0 || isLoading}
        speed={activeCount > 3 ? '1.5s' : '3s'}
      />
    </LoadingProgressContainer>
  );
};

export default GlobalLoadingIndicator;
