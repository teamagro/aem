import React, { useState, useEffect, createContext, useContext } from 'react';
import styled, { keyframes } from 'styled-components';

// Context for managing toasts
const ToastContext = createContext({
  addToast: () => {},
  removeToast: () => {},
  clearToasts: () => {}
});

// Toast animation keyframes
const slideIn = keyframes`
  from { transform: translateX(100%); opacity: 0; }
  to { transform: translateX(0); opacity: 1; }
`;

const slideOut = keyframes`
  from { transform: translateX(0); opacity: 1; }
  to { transform: translateX(100%); opacity: 0; }
`;

// Toast container
const ToastContainer = styled.div`
  position: fixed;
  top: 20px;
  right: 20px;
  max-width: 400px;
  z-index: 10000;
  display: flex;
  flex-direction: column;
  gap: 10px;
`;

// Individual toast
const ToastItem = styled.div`
  padding: 12px 16px;
  border-radius: 8px;
  color: #fff;
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
  display: flex;
  align-items: center;
  animation: ${props => props.isExiting ? slideOut : slideIn} 0.3s ease;
  background-color: ${props => {
    switch(props.type) {
      case 'success': return '#4caf50';
      case 'error': return '#f44336';
      case 'warning': return '#ff9800';
      case 'info': 
      default: return '#2196f3';
    }
  }};
  min-width: 250px;
`;

const ToastContent = styled.div`
  flex: 1;
`;

const ToastTitle = styled.div`
  font-weight: 500;
  margin-bottom: 4px;
`;

const ToastMessage = styled.div`
  font-size: 0.875rem;
  opacity: 0.9;
`;

const CloseButton = styled.button`
  background: none;
  border: none;
  color: white;
  font-size: 1rem;
  cursor: pointer;
  opacity: 0.7;
  transition: opacity 0.2s;
  padding: 0 0 0 16px;
  margin: 0;
  
  &:hover {
    opacity: 1;
  }
`;

// Toast provider component
export const ToastProvider = ({ children }) => {
  const [toasts, setToasts] = useState([]);
  
  const addToast = (toast) => {
    const id = Date.now().toString();
    const newToast = {
      id,
      title: toast.title || '',
      message: toast.message || '',
      type: toast.type || 'info',
      duration: toast.duration || 5000,
      isExiting: false
    };
    
    setToasts(prev => [...prev, newToast]);
    
    // Auto-dismiss after duration
    if (newToast.duration > 0) {
      setTimeout(() => {
        removeToast(id);
      }, newToast.duration);
    }
    
    return id;
  };
  
  const removeToast = (id) => {
    // Mark toast as exiting first to trigger animation
    setToasts(prev => 
      prev.map(toast => 
        toast.id === id ? { ...toast, isExiting: true } : toast
      )
    );
    
    // Remove toast after animation completes
    setTimeout(() => {
      setToasts(prev => prev.filter(toast => toast.id !== id));
    }, 300);
  };
  
  const clearToasts = () => {
    setToasts([]);
  };
  
  return (
    <ToastContext.Provider value={{ addToast, removeToast, clearToasts }}>
      {children}
      <ToastContainer>
        {toasts.map((toast) => (
          <ToastItem 
            key={toast.id} 
            type={toast.type}
            isExiting={toast.isExiting}
          >
            <ToastContent>
              {toast.title && <ToastTitle>{toast.title}</ToastTitle>}
              <ToastMessage>{toast.message}</ToastMessage>
            </ToastContent>
            <CloseButton onClick={() => removeToast(toast.id)}>&times;</CloseButton>
          </ToastItem>
        ))}
      </ToastContainer>
    </ToastContext.Provider>
  );
};

// Custom hook to use toast context
export const useToast = () => useContext(ToastContext);

// Success toast shorthand
export const useSuccessToast = () => {
  const { addToast } = useToast();
  return (message, title = 'Success') => addToast({ title, message, type: 'success' });
};

// Error toast shorthand
export const useErrorToast = () => {
  const { addToast } = useToast();
  return (message, title = 'Error') => addToast({ title, message, type: 'error' });
};

export default { ToastProvider, useToast, useSuccessToast, useErrorToast };
