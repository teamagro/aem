import React, { useEffect, useState } from 'react';
import styled from 'styled-components';
import { useLocation } from 'react-router-dom';
import useApiLoading from '../../hooks/useApiLoading';
import apiClient from '../../utils/apiClient';

const StatusContainer = styled.div`
  position: fixed;
  bottom: 20px;
  right: 20px;
  padding: 10px 15px;
  border-radius: 6px;
  background-color: ${props => props.theme.colors?.primary || '#4a7dfc'};
  color: white;
  font-size: 14px;
  box-shadow: 0 4px 10px rgba(0, 0, 0, 0.2);
  z-index: 9999;
  opacity: ${props => props.show ? 0.9 : 0};
  transform: translateY(${props => props.show ? '0' : '20px'});
  transition: opacity 0.3s ease, transform 0.3s ease;
  pointer-events: none;
  display: flex;
  align-items: center;
  gap: 8px;
`;

const LoadingDot = styled.span`
  width: 8px;
  height: 8px;
  background-color: white;
  border-radius: 50%;
  display: inline-block;
  animation: pulse 1.2s infinite ease-in-out;
  animation-delay: ${props => props.delay || '0s'};
  
  @keyframes pulse {
    0%, 100% { transform: scale(0.8); opacity: 0.8; }
    50% { transform: scale(1.2); opacity: 1; }
  }
`;

/**
 * Shows a status indicator in the corner of the screen when API operations are in progress
 */
const LoadingStatus = () => {
  const { isLoading, activeCount, activeRequests } = useApiLoading();
  const location = useLocation();
  
  // Only show for operations that take longer than 500ms
  const [showStatus, setShowStatus] = useState(false);
  
  // Hide status immediately on route change
  useEffect(() => {
    setShowStatus(false);
  }, [location]);
  
  useEffect(() => {
    let timer;
    
    if (isLoading) {
      timer = setTimeout(() => {
        setShowStatus(true);
      }, 500); // Only show loading status if operation takes longer than 500ms
    } else {
      setShowStatus(false);
    }
    
    return () => {
      if (timer) clearTimeout(timer);
    };
  }, [isLoading]);
  
  return (
    <StatusContainer show={showStatus}>
      <LoadingDot delay="0s" />
      <LoadingDot delay="0.2s" />
      <LoadingDot delay="0.4s" />
      {activeCount > 1 
        ? `${activeCount} operations in progress`
        : 'Loading...'}
    </StatusContainer>
  );
};

export default LoadingStatus;
