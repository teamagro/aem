import React, { useState, useEffect, useRef } from 'react';
import styled from 'styled-components';
import { useNavigate, useLocation } from 'react-router-dom';
import { useTheme } from '../context/ThemeContext';
import DashboardSidebar from '../components/dashboard/DashboardSidebar';
import { renderAsync } from 'docx-preview';
import mammoth from 'mammoth';
import { generateDocxFallbackPreview, getDocumentSource } from '../utils/docxPreview';
import ApiServiceEnhanced from '../services/ApiServiceEnhanced';
import useApiLoading from '../hooks/useApiLoading';
import useNavigationCleanup from '../hooks/useNavigationCleanup';
import { useToast } from '../components/common/Toast';
import config from '../config/config';

// Document Preview Cache to improve performance for cloud documents
const documentPreviewCache = {
  cache: {},
  set(documentId, html) {
    if (documentId && html) {
      this.cache[documentId] = {
        html,
        timestamp: Date.now()
      };
    }
  },
  get(documentId) {
    const entry = this.cache[documentId];
    if (entry) {
      // Cache entries expire after 1 hour
      const cacheValidTimeMs = 60 * 60 * 1000;
      if (Date.now() - entry.timestamp < cacheValidTimeMs) {
        return entry.html;
      } else {
        // Remove expired entry
        delete this.cache[documentId];
      }
    }
    return null;
  },
  has(documentId) {
    return !!this.get(documentId);
  },
  clear() {
    this.cache = {};
  }
};

const PageContainer = styled.div`
  display: flex;
  min-height: 100vh;
  background-color: ${props => props.theme.colors.background};
  color: ${props => props.theme.colors.text};
`;

const MainContent = styled.div`
  flex: 1;
  padding: 2rem;
  overflow-y: auto;
  margin-left: ${props => props.sidebarCollapsed ? '70px' : '240px'};
  width: calc(100% - ${props => props.sidebarCollapsed ? '70px' : '240px'});
  transition: margin-left 0.3s ease, width 0.3s ease;
  
  @media (max-width: 768px) {
    margin-left: 70px;
    width: calc(100% - 70px);
    padding: 1.5rem;
  }
`;

const Header = styled.div`
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 2rem;
`;

const PageTitle = styled.h1`
  font-size: 1.75rem;
  font-weight: 600;
  color: ${props => props.theme.colors.text};
  margin: 0;
`;

const StepperContainer = styled.div`
  display: flex;
  align-items: center;
  justify-content: center;
  margin-bottom: 2rem;
  padding: 1.5rem 0;
`;

const Step = styled.div`
  display: flex;
  flex-direction: column;
  align-items: center;
  position: relative;
  z-index: 1;
`;

const StepNumber = styled.div`
  width: 36px;
  height: 36px;
  border-radius: 50%;
  background-color: ${props => props.active ? props.theme.colors.primary : props.completed ? props.theme.colors.primary : props.theme.colors.primaryLight};
  display: flex;
  align-items: center;
  justify-content: center;
  color: ${props => props.active || props.completed ? 'white' : props.theme.colors.primary};
  font-weight: 600;
  font-size: 0.9rem;
  margin-bottom: 0.5rem;
`;

const StepLabel = styled.div`
  font-size: 0.8rem;
  color: ${props => props.active ? props.theme.colors.text : props.theme.colors.textSecondary};
  font-weight: ${props => props.active ? '500' : '400'};
  text-align: center;
  max-width: 100px;
`;

const StepConnector = styled.div`
  flex-grow: 1;
  height: 2px;
  background-color: ${props => props.completed ? props.theme.colors.primary : props.theme.colors.border};
  margin: 0 0.5rem;
  position: relative;
  top: -18px;
  z-index: 0;
`;

const ContentCard = styled.div`
  background-color: ${props => props.theme.colors.cardBackground};
  border-radius: 12px;
  border: 1px solid ${props => props.theme.colors.border};
  padding: 2rem;
  margin-bottom: 2rem;
  box-shadow: 0 4px 6px ${props => props.theme.colors.shadow};
`;

const CardTitle = styled.h2`
  font-size: 1.5rem;
  font-weight: 600;
  color: ${props => props.theme.colors.text};
  margin: 0 0 1.5rem 0;
`;

const MetadataSection = styled.div`
  margin-bottom: 2rem;
`;

const MetadataHeader = styled.div`
  display: flex;
  align-items: center;
  margin-bottom: 1rem;
`;

const SectionTitle = styled.h3`
  font-size: 1.1rem;
  font-weight: 500;
  color: ${props => props.theme.colors.text};
  margin: 0;
`;

const CompleteBadge = styled.div`
  display: flex;
  align-items: center;
  background-color: ${props => props.theme.colors.successLight};
  color: ${props => props.theme.colors.success};
  padding: 0.25rem 0.75rem;
  border-radius: 1rem;
  font-size: 0.75rem;
  font-weight: 500;
  margin-left: 1rem;
`;

const CompleteIcon = styled.div`
  width: 16px;
  height: 16px;
  border-radius: 50%;
  background-color: ${props => props.theme.colors.success};
  display: flex;
  align-items: center;
  justify-content: center;
  margin-right: 0.5rem;
  
  svg {
    width: 10px;
    height: 10px;
    color: white;
  }
`;

const MetadataGrid = styled.div`
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
  gap: 1rem;
  
  @media (max-width: 768px) {
    grid-template-columns: 1fr;
  }
`;

const MetadataCard = styled.div`
  background-color: ${props => props.theme.colors.borderLight};
  border-radius: 8px;
  border: 1px solid ${props => props.theme.colors.border};
  padding: 1rem;
`;

const MetadataLabel = styled.div`
  font-size: 0.8rem;
  color: ${props => props.theme.colors.textSecondary};
  margin-bottom: 0.25rem;
`;

const MetadataValue = styled.div`
  font-weight: 500;
  color: ${props => props.theme.colors.text};
  font-size: 0.95rem;
  word-break: break-all;
`;

const StatsGrid = styled.div`
  display: grid;
  grid-template-columns: repeat(6, 1fr);
  gap: 1rem;
  margin-top: .5rem;
  
  @media (max-width: 992px) {
    grid-template-columns: repeat(3, 1fr);
  }
  
  @media (max-width: 576px) {
    grid-template-columns: repeat(2, 1fr);
  }
`;

const StatCard = styled.div`
  background-color: ${props => props.theme.colors.borderLight};
  border-radius: 8px;
  border: 1px solid ${props => props.theme.colors.border};
  padding: 1rem;
`;

const StatValue = styled.div`
  font-size: 1.5rem;
  font-weight: 600;
  color: ${props => props.theme.colors.text};
  margin-bottom: 0.25rem;
`;

const StatLabel = styled.div`
  font-size: 0.8rem;
  color: ${props => props.theme.colors.textSecondary};
`;

const ActionContainer = styled.div`
  display: flex;
  justify-content: flex-end;
  margin-top: 2rem;
`;

const Button = styled.button`
  padding: 0.75rem 1.5rem;
  border-radius: 8px;
  font-size: 0.95rem;
  font-weight: 500;
  cursor: pointer;
  transition: all 0.2s ease;
`;

const CancelButton = styled(Button)`
  background-color: transparent;
  color: ${props => props.theme.colors.text};
  border: 1px solid ${props => props.theme.colors.border};
  margin-right: 1rem;
  
  &:hover {
    background-color: ${props => props.theme.colors.inputBackground};
  }
`;

const PrimaryButton = styled(Button)`
  background-color: ${props => props.theme.colors.primary};
  color: white;
  border: none;
  
  &:hover {
    background-color: ${props => props.theme.colors.primaryDark};
    transform: translateY(-2px);
    box-shadow: 0 4px 8px ${props => props.theme.colors.shadow};
  }
`;

const SecondaryButton = styled(Button)`
  background-color: transparent;
  color: ${props => props.theme.colors.text};
  border: 1px solid ${props => props.theme.colors.border};
  
  &:hover {
    background-color: ${props => props.theme.colors.inputBackground};
  }
`;

const BackButton = styled(Button)`
  background-color: transparent;
  color: ${props => props.theme.colors.text};
  border: 1px solid ${props => props.theme.colors.border};
  margin-right: 1rem;
  
  &:hover {
    background-color: ${props => props.theme.colors.inputBackground};
  }
`;

// Icon components
const CheckIcon = () => (
  <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <polyline points="20 6 9 17 4 12"></polyline>
  </svg>
);

const ArrowLeftIcon = () => (
  <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" style={{ marginRight: '0.5rem' }}>
    <line x1="19" y1="12" x2="5" y2="12"></line>
    <polyline points="12 19 5 12 12 5"></polyline>
  </svg>
);

const ClockIcon = () => (
  <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <circle cx="12" cy="12" r="10"></circle>
    <polyline points="12 6 12 12 16 14"></polyline>
  </svg>
);

const ServerIcon = () => (
  <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <rect x="2" y="2" width="20" height="8" rx="2" ry="2"></rect>
    <rect x="2" y="14" width="20" height="8" rx="2" ry="2"></rect>
    <line x1="6" y1="6" x2="6.01" y2="6"></line>
    <line x1="6" y1="18" x2="6.01" y2="18"></line>
  </svg>
);

const StepTitle = styled.h2`
  font-size: 1.5rem;
  font-weight: 600;
  margin-bottom: 1.5rem;
  color: ${props => props.theme.colors.text};
`;

const PreviewContainer = styled.div`
  border: 1px solid ${props => props.theme.colors.border};
  border-radius: 8px;
  overflow: hidden;
  margin-bottom: 2rem;
  background-color: ${props => props.theme.colors.inputBackground};
`;

const PreviewHeader = styled.div`
  padding: 1rem;
  background-color: ${props => props.theme.colors.cardBackground};
  border-bottom: 1px solid ${props => props.theme.colors.border};
  display: flex;
  align-items: center;
`;

const PreviewFrame = styled.div`
  width: 100%;
  height: 500px;
  background-color: white;
  display: flex;
  align-items: center;
  justify-content: center;
`;

// Add this new component for iframe-based preview
const WebsiteIframe = styled.iframe`
  width: 100%;
  height: 100%;
  border: none;
`;

const TabContainer = styled.div`
  display: flex;
  margin-bottom: 1.5rem;
  border-bottom: 1px solid ${props => props.theme.colors.border};
`;

const Tab = styled.div`
  padding: 0.75rem 1.5rem;
  cursor: pointer;
  font-weight: ${props => props.active ? '600' : '400'};
  color: ${props => props.active ? props.theme.colors.primary : props.theme.colors.text};
  border-bottom: 2px solid ${props => props.active ? props.theme.colors.primary : 'transparent'};
  
  &:hover {
    color: ${props => props.theme.colors.primary};
  }
`;

const DocumentPreview = styled.div`
  padding: 2rem;
  background-color: white;
  border-radius: 8px;
  box-shadow: 0 2px 4px ${props => props.theme.colors.shadow};
  color: #333;
  font-size: 0.9rem;
  line-height: 1.6;
  margin-bottom: 2rem;
  max-height: 400px;
  overflow-y: auto;
`;

// New styled components for UAT and Deployment steps
const TestingContainer = styled.div`
  margin-bottom: 2rem;
`;

const TestingGrid = styled.div`
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(350px, 1fr));
  gap: 1.5rem;
  margin-bottom: 2rem;
`;

const TestingCard = styled.div`
  background-color: ${props => props.theme.colors.cardBackground};
  border-radius: 8px;
  border: 1px solid ${props => props.theme.colors.border};
  padding: 1.5rem;
  box-shadow: 0 2px 4px ${props => props.theme.colors.shadow};
`;

const TestingCardHeader = styled.div`
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 1rem;
`;

const TestingTitle = styled.h4`
  font-size: 1.1rem;
  font-weight: 500;
  margin: 0;
`;

const TestingStatus = styled.div`
  padding: 0.25rem 0.75rem;
  border-radius: 1rem;
  font-size: 0.75rem;
  font-weight: 500;
  background-color: ${props =>
    props.status === 'Passed' ? props.theme.colors.successLight :
      props.status === 'Failed' ? props.theme.colors.errorLight :
        props.theme.colors.warningLight
  };
  color: ${props =>
    props.status === 'Passed' ? props.theme.colors.success :
      props.status === 'Failed' ? props.theme.colors.error :
        props.theme.colors.warning
  };
`;

const TestingDescription = styled.p`
  font-size: 0.9rem;
  color: ${props => props.theme.colors.text};
  margin-bottom: 1rem;
`;

const TestingDetails = styled.div`
  font-size: 0.85rem;
  color: ${props => props.theme.colors.textSecondary};
  
  p {
    margin: 0.5rem 0;
  }
`;

// New styled components for file tree and document preview
const FileExplorerContainer = styled.div`
  display: flex;
  gap: 1.5rem;
  margin-bottom: 2rem;
`;

const FileTreeContainer = styled.div`
  width: 280px;
  flex-shrink: 0;
  border: 1px solid ${props => props.theme.colors.border};
  border-radius: 8px;
  overflow: hidden;
  max-height: 600px;
`;

const FileTreeHeader = styled.div`
  padding: 0.75rem 1rem;
  background-color: ${props => props.theme.colors.cardBackground};
  border-bottom: 1px solid ${props => props.theme.colors.border};
  font-weight: 500;
  display: flex;
  justify-content: space-between;
  align-items: center;
`;

const FileTreeContent = styled.div`
  padding: 0.5rem;
  height: calc(100% - 40px);
  overflow-y: auto;
  background-color: ${props => props.theme.colors.inputBackground};
`;

const TreeFolder = styled.div`
  margin-bottom: 0.25rem;
`;

const TreeFolderHeader = styled.div`
  display: flex;
  align-items: center;
  padding: 0.25rem 0.5rem;
  cursor: pointer;
  border-radius: 4px;
  
  &:hover {
    background-color: ${props => props.theme.colors.borderLight};
  }
`;

const TreeFolderIcon = styled.div`
  margin-right: 0.5rem;
  color: ${props => props.theme.colors.primary};
  display: flex;
  align-items: center;
`;

const TreeFolderName = styled.div`
  font-size: 0.9rem;
  color: ${props => props.theme.colors.text};
`;

const TreeFolderContent = styled.div`
  padding-left: 1.25rem;
  margin-top: 0.25rem;
  border-left: 1px dotted ${props => props.theme.colors.border};
`;

const TreeFile = styled.div`
  padding: 0.25rem 0.5rem;
  margin-bottom: 0.25rem;
  display: flex;
  align-items: center;
  cursor: pointer;
  border-radius: 4px;
  transition: all 0.1s;
  
  ${props => props.active && `
    background-color: ${props.theme.colors.primary}25;
    font-weight: 500;
  `}
  
  &:hover {
    background-color: ${props => !props.active && props.theme.colors.borderLight};
  }
`;

const TreeFileIcon = styled.div`
  margin-right: 0.5rem;
  color: ${props => props.type === 'docx' ? '#2B579A' : props.type === 'pdf' ? '#FF5252' : props.theme.colors.textSecondary};
  display: flex;
  align-items: center;
`;

const TreeFileName = styled.div`
  font-size: 0.85rem;
  color: ${props => props.theme.colors.text};
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
`;

const PreviewContentContainer = styled.div`
  flex: 1;
  display: flex;
  flex-direction: column;
  overflow: hidden;
  border: 1px solid ${props => props.theme.colors.border};
  border-radius: 8px;
`;

const PreviewNavTabs = styled.div`
  display: flex;
  background-color: ${props => props.theme.colors.cardBackground};
  border-bottom: 1px solid ${props => props.theme.colors.border};
`;

const PreviewNavTab = styled.div`
  padding: 0.75rem 1.25rem;
  cursor: pointer;
  border-bottom: 2px solid ${props => props.active ? props.theme.colors.primary : 'transparent'};
  color: ${props => props.active ? props.theme.colors.primary : props.theme.colors.textSecondary};
  font-weight: ${props => props.active ? '500' : '400'};
  transition: all 0.2s;
  
  &:hover {
    color: ${props => props.theme.colors.primary};
  }
`;

const PreviewContent = styled.div`
  flex: 1;
  overflow: auto;
  background-color: ${props => props.theme.colors.inputBackground};
`;

const DocumentPreviewContainer = styled.div`
  background-color: white;
  min-height: 500px;
  padding: 1rem;
  box-shadow: 0 0 10px rgba(0,0,0,0.05) inset;
  display: flex;
  flex-direction: column;
  align-items: center;
  width: 100%;
  
  /* Styling for docx-preview content */
  .docx-wrapper {
    max-width: 100%;
    margin: 0 auto;
    padding: 0.5rem;
  }
  
  .docx-wrapper .docx-pages {
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
  }
  
  .docx-wrapper .docx-page {
    margin-bottom: 20px;
    border: 1px solid #e0e0e0;
    padding: 20px;
    background-color: white;
    box-shadow: 0 2px 5px rgba(0, 0, 0, 0.05);
  }
  
  /* Improve heading styles in DOCX preview */
  .docx-wrapper h1, .docx-wrapper h2, .docx-wrapper h3 {
    color: #2B579A;
  }
  
  .docx-wrapper table {
    border-collapse: collapse;
    margin: 1rem 0;
  }
  
  .docx-wrapper table td, .docx-wrapper table th {
    border: 1px solid #ddd;
    padding: 8px;
  }
  
  .docx-wrapper table tr:nth-child(even) {
    background-color: #f9f9f9;
  }
  
  /* Page number styling */
  .docx-wrapper .docx-page::after {
    content: attr(data-page-number);
    position: absolute;
    bottom: 20px;
    right: 20px;
    font-size: 12px;
    color: #777;
  }
`;

const DocumentPage = styled.div`
  width: 595px;
  min-height: 842px;
  background-color: white;
  box-shadow: 0 2px 8px rgba(0,0,0,0.15);
  padding: 72px 72px;
  margin-bottom: 2rem;
  position: relative;
`;

const PageNumber = styled.div`
  position: absolute;
  bottom: 36px;
  left: 0;
  right: 0;
  text-align: center;
  font-size: 0.8rem;
  color: #888;
`;

// File icon components
const FolderIcon = () => (
  <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <path d="M22 19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5l2 3h9a2 2 0 0 1 2 2z"></path>
  </svg>
);

const DocxFileIcon = () => (
  <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path>
    <polyline points="14 2 14 8 20 8"></polyline>
    <line x1="16" y1="13" x2="8" y2="13"></line>
    <line x1="16" y1="17" x2="8" y2="17"></line>
    <polyline points="10 9 9 9 8 9"></polyline>
  </svg>
);

const PageCard = styled.div`
  background-color: ${props => props.theme.colors.cardBackground};
  border-radius: 8px;
  overflow: hidden;
  border: 1px solid ${props => props.theme.colors.border};
  transition: all 0.2s;
  display: flex;
  flex-direction: column;
  
  &:hover {
    transform: translateY(-3px);
    box-shadow: 0 4px 8px ${props => props.theme.colors.shadow};
  }
`;

const PageCardImagePreview = styled.div`
  width: 100%;
  height: 160px;
  background-color: ${props => props.theme.colors.inputBackground};
  display: flex;
  align-items: center;
  justify-content: center;
  position: relative;
  overflow: hidden;
  
  img {
    width: 100%;
    height: 100%;
    object-fit: cover;
  }
`;

const PageCardStatusBadge = styled.div`
  position: absolute;
  top: 10px;
  right: 10px;
  width: 24px;
  height: 24px;
  border-radius: 50%;
  background-color: ${props => props.theme.colors.success};
  display: flex;
  align-items: center;
  justify-content: center;
  color: white;
  z-index: 1;
`;

const PageCardInfo = styled.div`
  padding: 1rem;
  display: flex;
  flex-direction: column;
  flex: 1;
`;

const PageCardHeader = styled.div`
  display: flex;
  justify-content: space-between;
  align-items: flex-start;
  margin-bottom: 0.75rem;
`;

const PageCardTitle = styled.div`
  font-weight: 500;
  font-size: 1rem;
  color: ${props => props.theme.colors.text};
`;

const PageCardPath = styled.div`
  font-size: 0.8rem;
  color: ${props => props.theme.colors.textSecondary};
  margin-top: 0.25rem;
`;

const PageCardConfidence = styled.div`
  background-color: ${props => props.theme.colors.successLight};
  color: ${props => props.theme.colors.success};
  padding: 0.25rem 0.5rem;
  border-radius: 4px;
  display: inline-block;
  font-weight: 500;
  font-size: 0.75rem;
  white-space: nowrap;
`;

const PageCardStats = styled.div`
  display: flex;
  justify-content: space-between;
  margin: 0.75rem 0;
  padding-top: 0.75rem;
  border-top: 1px solid ${props => props.theme.colors.border};
`;

const PageCardStat = styled.div`
  display: flex;
  flex-direction: column;
  align-items: center;
`;

const PageCardStatValue = styled.div`
  font-weight: 500;
  font-size: 1rem;
  color: ${props => props.theme.colors.text};
`;

const PageCardStatLabel = styled.div`
  font-size: 0.75rem;
  color: ${props => props.theme.colors.textSecondary};
`;

const PageCardFooter = styled.div`
  display: flex;
  gap: 0.5rem;
  margin-top: auto;
  padding-top: 0.75rem;
  justify-content: flex-end;
`;

// File section styled components
const UploadedFilesSection = styled.div`
  margin-top: 2rem;
`;

const FilesHeader = styled.div`
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 1rem;
`;

const FilesTitle = styled.h3`
  font-size: 1.1rem;
  font-weight: 500;
  margin: 0;
`;

const FilesGrid = styled.div`
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(180px, 1fr));
  gap: 1rem;
`;

const FileCard = styled.div`
  background-color: ${props => props.theme.colors.inputBackground};
  border-radius: 8px;
  overflow: hidden;
  border: 1px solid ${props => props.theme.colors.border};
  transition: all 0.2s;
  
  &:hover {
    transform: translateY(-3px);
    box-shadow: 0 4px 8px ${props => props.theme.colors.shadow};
  }
`;

const FileImagePreview = styled.div`
  width: 100%;
  height: 120px;
  background-color: ${props => props.theme.colors.cardBackground};
  display: flex;
  align-items: center;
  justify-content: center;
  overflow: hidden;
  
  img {
    width: 100%;
    height: 100%;
    object-fit: cover;
  }
`;

const FileIconPreview = styled.div`
  width: 100%;
  height: 120px;
  background-color: ${props => props.backgroundColor || props.theme.colors.cardBackground};
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  color: white;
  font-size: 2rem;
`;

const FileInfo = styled.div`
  padding: 0.75rem;
`;

const FileName = styled.div`
  font-weight: 500;
  font-size: 0.9rem;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
  color: ${props => props.theme.colors.text};
`;

const FileSize = styled.div`
  font-size: 0.8rem;
  color: ${props => props.theme.colors.textSecondary};
  margin-top: 0.25rem;
`;

// File icon components
const PdfFileIcon = () => (
  <svg xmlns="http://www.w3.org/2000/svg" width="36" height="36" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path>
    <polyline points="14 2 14 8 20 8"></polyline>
    <path d="M9 15h6"></path>
    <path d="M9 11h6"></path>
  </svg>
);

const ZipFileIcon = () => (
  <svg xmlns="http://www.w3.org/2000/svg" width="36" height="36" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <path d="M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z"></path>
    <polyline points="3.29 7 12 12 20.71 7"></polyline>
    <line x1="12" y1="22" x2="12" y2="12"></line>
  </svg>
);

// Format file size helper function
const formatFileSize = (bytes) => {
  if (bytes < 1024) return bytes + ' B';
  else if (bytes < 1048576) return (bytes / 1024).toFixed(1) + ' KB';
  else return (bytes / 1048576).toFixed(1) + ' MB';
};

// Get file color based on file extension
const getFileColor = (extension) => {
  switch (extension) {
    case 'pdf': return '#FF5252';
    case 'zip': return '#FFA000';
    case 'png': case 'jpg': case 'jpeg': return '#4CAF50';
    default: return '#78909C';
  }
};

// Get file icon based on file extension
const getFileIcon = (extension) => {
  switch (extension) {
    case 'pdf': return <PdfFileIcon />;
    case 'zip': return <ZipFileIcon />;
    default: return <PdfFileIcon />;
  }
};

// Deployment styled components
const DeploymentContainer = styled.div`
  margin-bottom: 2rem;
`;

const DeploymentSteps = styled.div`
  display: flex;
  flex-direction: column;
  gap: 1.5rem;
  margin-bottom: 2rem;
  padding: 1rem 0;
`;

const DeploymentStep = styled.div`
  display: flex;
  gap: 1rem;
`;

const StepIcon = styled.div`
  width: 36px;
  height: 36px;
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
  flex-shrink: 0;
  background-color: ${props =>
    props.status === 'completed' ? props.theme.colors.success :
      props.status === 'in-progress' ? props.theme.colors.warning :
        props.theme.colors.borderLight
  };
  color: ${props =>
    props.status === 'completed' || props.status === 'in-progress' ? 'white' :
      props.theme.colors.textSecondary
  };
  font-weight: 600;
  font-size: 0.9rem;
`;

const StepContent = styled.div`
  flex: 1;
`;

const StepContentHeader = styled.div`
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 0.5rem;
`;

const StepName = styled.div`
  font-weight: 500;
  font-size: 1rem;
  color: ${props => props.theme.colors.text};
`;

const StepTime = styled.div`
  font-size: 0.85rem;
  color: ${props => props.theme.colors.textSecondary};
`;

const EnvironmentContainer = styled.div`
  display: grid;
  grid-template-columns: repeat(3, 1fr);
  gap: 1.5rem;
  
  @media (max-width: 992px) {
    grid-template-columns: repeat(2, 1fr);
  }
  
  @media (max-width: 576px) {
    grid-template-columns: 1fr;
  }
`;

const EnvironmentCard = styled.div`
  background-color: ${props => props.theme.colors.cardBackground};
  border-radius: 8px;
  border: 1px solid ${props => props.theme.colors.border};
  padding: 1.5rem;
  
  h5 {
    font-size: 1.1rem;
    font-weight: 500;
    margin: 0 0 1rem 0;
    color: ${props => props.theme.colors.text};
    display: flex;
    align-items: center;
  }
`;

// Missing PageCardsGrid component
const PageCardsGrid = styled.div`
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(280px, 1fr));
  gap: 1.5rem;
  margin-top: 1rem;
`;

const AdobeFranklinProject = () => {
  if (localStorage.getItem('analysis_api_call')) {
    localStorage.removeItem('analysis_api_call')
  }
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false);
  const { theme } = useTheme();
  const navigate = useNavigate();
  const location = useLocation();
  const toast = useToast();

  // Clean up loading states on navigation or unmount
  useNavigationCleanup();

  // Set the active step (1-based index)
  const [activeStep, setActiveStep] = useState(1);
  const [activeTab, setActiveTab] = useState('html');
  const [previewTab, setPreviewTab] = useState('document'); // Options: 'document', 'web'
  const [selectedFile, setSelectedFile] = useState(null);
  const [expandedFolders, setExpandedFolders] = useState(['src', 'components', 'documents']);
  const [searchQuery, setSearchQuery] = useState('');
  const [isDocLoading, setIsDocLoading] = useState(false);
  const docxPreviewRef = useRef(null);
  const [kbMetadata, setKbMetadata] = useState(null); // State to store kbMetadata
  const [isLoading, setIsLoading] = useState(true); // Loading state
  const [analysisMetadata, setAnalysisMetadata] = useState(null); // State to store analysisMetadata
  const [isAnalysisLoading, setIsAnalysisLoading] = useState(true); // Loading state for analysisMetadata
  const [apiStartTime, setApiStartTime] = useState(null);
  const [elapsedTime, setElapsedTime] = useState('0:00');
  const [timerInterval, setTimerInterval] = useState(null);

  // Add a new state for project analysis
  const [projectAnalysis, setProjectAnalysis] = useState([]);
  const [isAnalysisDataLoading, setIsAnalysisDataLoading] = useState(true);
  const [documentHierarchy, setDocumentHierarchy] = useState([]);

  // Debug logging function to track ref status
  const debugLogRefStatus = (ref, name) => {
    console.log(`Debug - ${name} ref status:`, ref?.current ? 'Available' : 'NULL');
    if (ref?.current) {
      console.log(`Debug - ${name} element:`, ref.current);
    }
  };

  // Get uploaded files from router state
  const [uploadedFiles, setUploadedFiles] = useState([]);
  const [projectId, setProjectId] = useState(null);

  const project_details = location.state?.projectData;

  // Use effect to load project data from router state when component mounts
  useEffect(() => {
    let pid = null;
    if (location.state?.projectData?.id) {
      pid = location.state.projectData.id;
    } else if (localStorage.getItem('project_id')) {
      pid = localStorage.getItem('project_id');
    }
    if (pid) {
      setProjectId(pid);
      // Fetch uploaded images from backend
      ApiServiceEnhanced.getProjectImages(pid)
        .then(images => {
          // Map backend image data to frontend file structure
          setUploadedFiles(images.map(img => {
            const baseUrl = config.API_BASE_URL.replace('/api/v1', '');
            // Ensure no double slashes in the URL and convert backslashes to slashes
            const cleanPath = img.filepath.replace(/\\/g, '/');
            return {
              name: img.filename,
              extension: img.filename.split('.').pop().toLowerCase(),
              size: img.file_size,
              previewUrl: `${baseUrl}/${cleanPath}`,
              id: img.id
            };
          }));
        })
        .catch(err => {
          setUploadedFiles([]);
        });
    }
  }, [location.state]);

  // Project data
  const projectData = {
    name: 'AEM Sidekick Library',
    url: 'https://main--test--teamagro.aem.page/',
    brand: 'ABC',
    totalBlocks: 24,
    globalBlocks: 2,
    siteBuildingBlocks: 22, generatedFiles: [
      {
        id: 'doc-1',
        name: 'AEM Franklin Components.docx',
        type: 'docx',
        path: 'https://drive.google.com/file/d/1abc123xyz/view',
        relativePath: '/cloud/google-drive/AEM Franklin Components.docx',
        size: 425000,
        lastModified: 'May 9, 2025'
      },
      {
        id: 'doc-2',
        name: 'services.docx',
        type: 'docx',
        path: 'https://drive.google.com/drive/u/0/folders/1EJWovZy44rGV0q3ls0qpBdMHoBKijUwz',
        relativePath: '/cloud/google-drive/services.docx',
        size: 425000,
        lastModified: 'May 11, 2025'
      },
      {
        id: 'doc-3',
        name: 'nav.docx',
        type: 'docx',
        path: 'https://drive.google.com/file/d/1EJWovZy44rGV0q3ls0qpBdMHoBKijUwz/view',
        relativePath: '/cloud/google-drive/nav.docx',
        size: 380000,
        lastModified: 'May 11, 2025'
      },
      {
        id: 'doc-4',
        name: 'index.docx',
        type: 'docx',
        path: 'https://drive.google.com/file/d/1EJWovZy44rGV0q3ls0qpBdMHoBKijUwz/view',
        relativePath: '/cloud/google-drive/index.docx',
        size: 510000,
        lastModified: 'May 11, 2025'
      },
      {
        id: 'doc-5',
        name: 'footer.docx',
        type: 'docx',
        path: 'https://drive.google.com/file/d/1EJWovZy44rGV0q3ls0qpBdMHoBKijUwz/view',
        relativePath: '/cloud/google-drive/footer.docx',
        size: 290000,
        lastModified: 'May 11, 2025'
      },
      {
        id: 'doc-6',
        name: 'contact.docx',
        type: 'docx',
        path: 'https://drive.google.com/file/d/1EJWovZy44rGV0q3ls0qpBdMHoBKijUwz/view',
        relativePath: '/cloud/google-drive/contact.docx',
        size: 340000,
        lastModified: 'May 11, 2025'
      },
      {
        id: 'doc-7',
        name: 'components.docx',
        type: 'docx',
        path: 'https://drive.google.com/file/d/1EJWovZy44rGV0q3ls0qpBdMHoBKijUwz/view',
        relativePath: '/cloud/google-drive/components.docx',
        size: 485000,
        lastModified: 'May 11, 2025'
      },
      {
        id: 'doc-8',
        name: 'about.docx',
        type: 'docx',
        path: 'https://drive.google.com/file/d/1EJWovZy44rGV0q3ls0qpBdMHoBKijUwz/view',
        relativePath: '/cloud/google-drive/about.docx',
        size: 372000,
        lastModified: 'May 11, 2025'
      }
    ],
    designMetadata: {
      progress: '10/10 (100%)',
      pages: 10,
      links: 27,
      images: 20,
      blocks: 75,
      forms: 0,
      videos: 0
    },
    components: [
      {
        name: 'Header',
        description: 'Global navigation component with logo, menu and search',
        progress: 100
      },
      {
        name: 'Footer',
        description: 'Site footer with links, copyright and social media icons',
        progress: 100
      },
      {
        name: 'Hero Banner',
        description: 'Primary banner with image background, heading and CTA',
        progress: 80
      },
      {
        name: 'Card Grid',
        description: 'Grid layout for displaying card components',
        progress: 65
      },
      {
        name: 'Testimonial',
        description: 'Customer quote with avatar and attribution',
        progress: 90
      },
      {
        name: 'Contact Form',
        description: 'Form component with validation and submission',
        progress: 50
      }
    ],
    generatedCode: {
      html: '<header class="header">\n  <div class="container">\n    <div class="logo">Logo</div>\n    <nav class="nav">Menu items</nav>\n  </div>\n</header>',
      css: '.header {\n  background-color: #ffffff;\n  box-shadow: 0 2px 4px rgba(0,0,0,0.1);\n  position: sticky;\n  top: 0;\n  z-index: 100;\n}\n\n.container {\n  display: flex;\n  justify-content: space-between;\n  align-items: center;\n  max-width: 1200px;\n  margin: 0 auto;\n  padding: 1rem;\n}',
      js: 'document.addEventListener("DOMContentLoaded", function() {\n  const nav = document.querySelector(".nav");\n  const mobileToggle = document.createElement("button");\n  mobileToggle.className = "mobile-toggle";\n  \n  mobileToggle.addEventListener("click", function() {\n    nav.classList.toggle("active");\n  });\n});'
    },
    documentation: `# AEM Sidekick Library 
    ## Overview
    This project contains components built using Adobe Franklin technology. The components are designed to be reusable across Adobe Experience Manager sites.
    ## Components
    1. **Header Component**
      - Global navigation with dropdown support
      - Responsive behavior for mobile devices
      - Search functionality

    2. **Footer Component**
      - Copyright information
      - Navigation links
      - Social media integration
        
    ## Getting Started
    To use these components in your AEM project, follow these steps...`,
    // Adding UAT and deployment data for steps 5 and 6
    userAcceptanceTests: [
      {
        id: 'test-1',
        name: 'Header Navigation',
        status: 'Passed',
        description: 'Verify header navigation links work correctly',
        tester: 'John Doe',
        date: '2025-05-07',
        notes: 'All links working as expected'
      },
      {
        id: 'test-2',
        name: 'Responsive Layout',
        status: 'Passed',
        description: 'Test website responsiveness on multiple devices',
        tester: 'Jane Smith',
        date: '2025-05-07',
        notes: 'Works well on desktop and mobile'
      },
      {
        id: 'test-3',
        name: 'Contact Form Validation',
        status: 'Failed',
        description: 'Verify form validations and submission',
        tester: 'John Doe',
        date: '2025-05-07',
        notes: 'Email validation not working correctly'
      },
      {
        id: 'test-4',
        name: 'Image Optimization',
        status: 'In Progress',
        description: 'Check if images are properly optimized',
        tester: 'Jane Smith',
        date: '2025-05-08',
        notes: 'Testing in progress'
      }
    ],
    deploymentStages: [
      {
        id: 'stage-1',
        name: 'Build and Compile',
        status: 'completed',
        description: 'Build and compile project assets',
        time: '10:30 AM, May 8, 2025'
      },
      {
        id: 'stage-2',
        name: 'Deploy to Staging',
        status: 'in-progress',
        description: 'Deploy to staging environment for final testing',
        time: '11:15 AM, May 8, 2025'
      },
      {
        id: 'stage-3',
        name: 'Deploy to Production',
        status: 'pending',
        description: 'Deploy to production environment',
        time: 'Scheduled for 2:00 PM, May 8, 2025'
      }
    ],
    environments: [
      {
        name: 'Development',
        url: 'https://main--test--teamagro.aem.page/',
        status: 'Online',
        lastDeployed: 'May 11, 2025, 10:00 PM'
      },
      {
        name: 'Staging',
        url: 'https://stage--main--test--teamagro.aem.page/',
        status: 'Deploying',
        lastDeployed: 'NA',
      },
      {
        name: 'Production',
        url: 'https://main--test--teamagro.aem.page/',
        status: 'Pending',
        lastDeployed: 'NA',
      }
    ]
  };

  // Initialize selectedFile if not set when in document & preview step
  useEffect(() => {
    if (activeStep === 3 && !selectedFile) {
      // First check if we have document hierarchy data from the API
      if (documentHierarchy && Array.isArray(documentHierarchy) && documentHierarchy.length > 0) {
        console.log('Auto-selecting first document from documentHierarchy:', documentHierarchy[0]);

        // Set the selected file state
        setSelectedFile(documentHierarchy[0]);

        // Set preview tab to document
        setPreviewTab('document');

        // Check if it's a DOCX file
        const firstFile = documentHierarchy[0];
        const isDocxFile = firstFile.type === 'docx' ||
          (firstFile.name && firstFile.name.toLowerCase().endsWith('.docx'));

        if (isDocxFile) {
          // Using a multi-phase loading approach to ensure reliability
          setIsDocLoading(true);
        }
      }
      // No documents found in the hierarchy - show error message
      else {
        console.warn('No documents found in documentHierarchy data');
        
        // Set preview tab to document
        setPreviewTab('document');
        
        // Add a brief delay to ensure the container is ready
        setTimeout(() => {
          if (docxPreviewRef.current) {
            // Display error message in the preview container
            docxPreviewRef.current.innerHTML = `
              <div style="padding: 2rem; text-align: center; color: #555;">
                <div style="margin-bottom: 1rem; font-size: 16px; color: #e74c3c;">
                  No Documents Available
                </div>
                <div style="color: #777; font-size: 14px;">
                  No documents found in the document hierarchy.
                </div>
                <div style="margin-top: 1rem;">
                  <button 
                    style="padding: 0.5rem 1rem; background-color: #3498db; color: white; border: none; border-radius: 4px; cursor: pointer;"
                    onclick="window.location.reload()">
                    Refresh Page
                  </button>
                </div>
              </div>
            `;
          }
        }, 500);
      }
    }
  }, [activeStep, selectedFile, documentHierarchy, projectData]);

  // Add effect to monitor the status of docxPreviewRef and ensure proper rendering
  useEffect(() => {
    // Log the ref status when the step changes or when the component mounts
    if (activeStep === 3) {
      // Create a series of checks at increasing intervals to ensure the ref is available
      const checkIntervals = [100, 300, 600, 1000, 2000]; // Increasing intervals

      const checkRef = (intervals, index = 0) => {
        if (index >= intervals.length) return; // Stop if we've tried all intervals

        setTimeout(() => {
          debugLogRefStatus(docxPreviewRef, `docxPreview (check ${index + 1}/${intervals.length})`);

          // If ref still not available, try again at next interval
          if (!docxPreviewRef.current && index < intervals.length - 1) {
            checkRef(intervals, index + 1);
          }
          // If ref becomes available at any point and we have a selected file, load the preview
          else if (docxPreviewRef.current && selectedFile) {
            console.log('Ref is now available, attempting to load preview again');
            loadDocxPreview(selectedFile);
          }
        }, intervals[index]);
      };

      // Start the check sequence
      checkRef(checkIntervals);
    }
  }, [activeStep, selectedFile]);

  // Add special effect for document preview DOM initialization and monitoring
  useEffect(() => {
    if (activeStep === 3) {
      console.log("Document preview step active - initializing DOM monitoring");

      // Function to ensure the preview container exists and is ready
      const ensurePreviewContainer = () => {
        // Try to find the container even if the ref isn't set yet
        let containerElement = docxPreviewRef.current;

        if (!containerElement) {
          // Try to find by ID if ref is not working
          containerElement = document.getElementById('docx-preview-container');
          console.log('Looking for container by ID:', containerElement ? 'Found' : 'Not found');

          // If found, attempt to set the ref manually (this is a fallback)
          if (containerElement && !docxPreviewRef.current) {
            // Note: This is only for debugging - in React we shouldn't manually set refs
            console.log('Container found by ID but ref is null - unusual situation');
          }
        }

        // If we found the container element, make sure it's properly prepared
        if (containerElement) {
          // Ensure it has minimal content to maintain its dimensions
          if (!containerElement.innerHTML || containerElement.innerHTML.trim() === '') {
            containerElement.innerHTML = `<div style="padding: 1rem; text-align: center; color: #888">
              Document preview area ready. Select a document to view.
            </div>`;
          }

          // Log successful initialization
          console.log('Document preview container initialized successfully');

          // If we have a selected file, try loading the preview again
          if (selectedFile && !isDocLoading) {
            console.log('Container ready and file selected - loading preview');
            loadDocxPreview(selectedFile);
          }
        }
      };

      // Initial check with a delay to allow for DOM rendering
      const initTimeout = setTimeout(ensurePreviewContainer, 800);

      // Return cleanup function
      return () => {
        clearTimeout(initTimeout);
      };
    }
  }, [activeStep, selectedFile, isDocLoading]);

  // Handle sidebar toggle
  const handleSidebarToggle = (collapsed) => {
    setSidebarCollapsed(collapsed);
  };

  // Toggle folder expand/collapse
  const toggleFolder = (folder) => {
    setExpandedFolders(prevFolders => {
      if (prevFolders.includes(folder)) {
        return prevFolders.filter(f => f !== folder);
      } else {
        return [...prevFolders, folder];
      }
    });
  };

  // Check if a folder is expanded
  const isFolderExpanded = (folder) => {
    return expandedFolders.includes(folder);
  };  // Handle file selection
  const handleFileSelect = (file) => {
    console.log('Selected file:', file);
    setSelectedFile(file);
    setPreviewTab('document');

    // Detect DOCX files either from type property or by name extension
    const isDocxFile = file && (file.type === 'docx' || (file.name && file.name.toLowerCase().endsWith('.docx')));

    // Trigger DOCX preview loading
    if (isDocxFile) {
      console.log(`Loading DOCX preview for ${file.name}`);

      // Reset loading state
      setIsDocLoading(true);

      // First, check if docxPreviewRef is available
      if (docxPreviewRef.current) {
        // Show a temporary loading message
        docxPreviewRef.current.innerHTML = `
          <div style="padding: 2rem; text-align: center; color: #555;">
            <div style="margin-bottom: 1rem; font-size: 16px;">
              Preparing preview for: ${file.name}
            </div>
            <div style="color: #777; font-size: 14px;">
              Please wait while the document is being processed...
            </div>
          </div>
        `;

        // Add a delay before actual loading to ensure UI updates
        setTimeout(() => {
          loadDocxPreview(file);
        }, 300);
      } else {
        // If ref not available, try to find or create the container
        console.log('docxPreviewRef.current is null in handleFileSelect, looking for alternative container');

        // Try to find the container by ID
        const container = document.getElementById('docx-preview-container') ||
          document.querySelector('.docx-preview-container');

        if (container) {
          console.log('Found container element by query, using it for preview');
          container.innerHTML = `
            <div style="padding: 2rem; text-align: center; color: #555;">
              <div style="margin-bottom: 1rem; font-size: 16px;">
                Preparing preview for: ${file.name}
              </div>
              <div style="color: #777; font-size: 14px;">
                Please wait while the document is being processed...
              </div>
            </div>
          `;
        }

        // Use the loadDocxPreview function with enhanced retry capabilities
        setTimeout(() => {
          loadDocxPreview(file);
        }, 600); // Use a longer delay when ref is not immediately available
      }
    } else {
      // Get file extension from name
      const fileExtension = file.name ? file.name.split('.').pop().toLowerCase() : 'unknown';
      console.log(`File type not supported for preview. Name: ${file.name}, Extension: ${fileExtension}`);

      // For unsupported file types, show message with a more robust approach
      const showUnsupportedMessage = () => {
        // Try multiple methods to find/access the container
        if (docxPreviewRef.current) {
          docxPreviewRef.current.innerHTML = `
            <div style="padding: 2rem; text-align: center;">
              <p>Preview not available for ${file.name}</p>
              <p>File extension: ${fileExtension}</p>
            </div>
          `;
        } else {
          console.warn('docxPreviewRef.current is null when showing unsupported message. Looking for alternative containers...');

          // Try alternative methods to find the container
          const container = document.getElementById('docx-preview-container') ||
            document.querySelector('.docx-preview-container');

          if (container) {
            container.innerHTML = `
              <div style="padding: 2rem; text-align: center;">
                <p>Preview not available for ${file.name}</p>
                <p>File extension: ${fileExtension}</p>
              </div>
            `;
          } else {
            // If still can't find container, retry once more
            setTimeout(showUnsupportedMessage, 500);
          }
        }
      };
      // Start the process
      showUnsupportedMessage();
    }
  };

  // Function to load and render DOCX preview with cloud support
  const loadDocxPreview = async (file) => {
    setIsDocLoading(true);

    try {
      // Check if we have a cached preview for this document
      if (documentPreviewCache.has(file.id)) {
        console.log(`Using cached preview for document: ${file.name}`);

        if (docxPreviewRef.current) {
          docxPreviewRef.current.innerHTML = documentPreviewCache.get(file.id);
          setIsDocLoading(false);
          return;
        }
      }

      const documentSource = getDocumentSource(file);
      console.log(`Loading DOCX file from ${documentSource.type === 'cloud' ? documentSource.service : 'local'} path: ${file.path}`);

      // Verify this is actually a DOCX file
      const isDocxFile = file.type === 'docx' ||
        (file.name && file.name.toLowerCase().endsWith('.docx'));

      if (!isDocxFile) {
        console.warn(`File ${file.name} is not a DOCX file. Skipping preview.`);
        setIsDocLoading(false);

        if (docxPreviewRef.current) {
          docxPreviewRef.current.innerHTML = `
            <div style="padding: 2rem; text-align: center;">
              <p>Preview not available for ${file.name}</p>
              <p>This is not a DOCX file.</p>
            </div>
          `;
        } else {
          console.warn('docxPreviewRef.current is null. Cannot display error message');
        }
        return;
      }

      // Enhanced retry mechanism with increasing delays between attempts
      // This helps handle cases where the DOM is still being constructed or updated
      const maxRetries = 8; // Increased max retries for more attempts
      const baseRetryDelay = 300;
      let currentRetry = 0;
      const attemptPreviewRender = () => {
        // Get document source information
        const documentSource = getDocumentSource(file);

        // Check if component is still mounted and in the DOM
        const componentMounted = docxPreviewRef.current && document.body.contains(docxPreviewRef.current);

        if (componentMounted) {
          try {
            console.log("Document preview container found in DOM, proceeding with rendering");

            // Clear any previous content
            docxPreviewRef.current.innerHTML = '';

            // Force a browser reflow to ensure the DOM is updated
            void docxPreviewRef.current.offsetHeight;

            // Handle cloud documents differently
            if (documentSource.type === 'cloud') {
              // Show loading message specific to cloud sources
              docxPreviewRef.current.innerHTML = `
                <div style="padding: 2rem; text-align: center; color: #555;">
                  <div style="font-size: 48px; margin-bottom: 20px;">${documentSource.icon}</div>
                  <div style="margin-bottom: 1rem; font-size: 16px;">
                    Loading document from ${documentSource.label}
                  </div>
                  <div style="color: #777; font-size: 14px;">
                    Retrieving ${file.name} from cloud storage...
                  </div>
                  <div style="margin-top: 20px; font-size: 12px; color: #999;">
                    URL: ${file.path}
                  </div>
                </div>`;

              setTimeout(() => {
                // Handle Google Docs and Google Drive documents properly
                if (documentSource.service === 'google-drive') {
                  try {
                    // Use the URL from the document JSON directly
                    let embeddingUrl = file.path;

                    // Create embedded iframe for Google Docs
                    docxPreviewRef.current.innerHTML = `
                      <div style="width: 100%; height: 100%; min-height: 500px; padding: 1rem;">
                        <iframe 
                          src="${embeddingUrl}" 
                          style="width: 100%; height: 100%; min-height: 600px; border: 1px solid #e0e0e0;"
                          frameborder="0"
                          allowfullscreen="true"
                          mozallowfullscreen="true"
                          webkitallowfullscreen="true">
                        </iframe>
                        <div style="margin-top: 10px; text-align: right;">
                          <a href="${file.path}" target="_blank" style="text-decoration: none; color: #1a73e8; font-size: 14px;">
                            Open in Google Docs ↗
                          </a>
                        </div>
                      </div>
                    `;
                    console.log("Google Doc preview embedded successfully");
                    
                    // Cache the preview HTML for future use
                    documentPreviewCache.set(file.id, docxPreviewRef.current.innerHTML);
                    
                    // Indicate loading is complete
                    setIsDocLoading(false);
                  } catch (embedError) {
                    console.error("Error rendering Google Doc preview:", embedError);
                    // Attempt to display error message if preview container is available
                    if (docxPreviewRef.current) {
                      docxPreviewRef.current.innerHTML = `
                        <div style="padding: 2rem; text-align: center;">
                          <p>Error loading cloud document: ${file.name}</p>
                          <p>Source: ${documentSource.label}</p>
                          <p>Please try opening the document directly in your browser.</p>
                          <button onclick="window.open('${file.path}', '_blank')" 
                                  style="padding: 8px 16px; margin-top: 1rem; cursor: pointer;">
                            Open in Browser
                          </button>
                        </div>
                      `;
                    }
                    setIsDocLoading(false);
                  }
                } else {
                  // For other cloud sources, use fallback preview
                  try {
                    // Generate preview HTML using our utility
                    const previewHtml = generateDocxFallbackPreview(file, projectData.components || []);

                    // Check if the ref is still valid before updating
                    if (docxPreviewRef.current) {
                      docxPreviewRef.current.innerHTML = previewHtml;
                      console.log("Cloud document preview generated successfully");

                      // Cache the preview HTML for future use
                      documentPreviewCache.set(file.id, previewHtml);
                    } else {
                      console.error("Preview container not available when rendering cloud document");
                    }
                  } catch (previewError) {
                    console.error("Error rendering fallback preview:", previewError);
                    if (docxPreviewRef.current) {
                      docxPreviewRef.current.innerHTML = `
                        <div style="padding: 2rem; text-align: center;">
                          <p>Error loading cloud document: ${file.name}</p>
                          <p>Source: ${documentSource.label}</p>
                          <p>Please try opening the document directly in your browser.</p>
                          <button onclick="window.open('${file.path}', '_blank')" 
                                  style="padding: 8px 16px; margin-top: 1rem; cursor: pointer;">
                            Open in Browser
                          </button>
                        </div>
                      `;
                    }
                  } finally {
                    setIsDocLoading(false);
                  }
                }
              }, 1500);
            } else {
              // For local files, use the direct preview approach
              const previewHtml = generateDocxFallbackPreview(file, projectData.components || []);

              // Check if the ref is still valid before updating its content
              if (docxPreviewRef.current) {
                docxPreviewRef.current.innerHTML = previewHtml;
                console.log("Local document preview generated successfully");
              } else {
                console.error("Preview container was removed from DOM during rendering");
              }
              setIsDocLoading(false);
            }
          } catch (error) {
            console.error("Error generating DOCX preview:", error);
            // Final fallback for error display with context-aware message
            if (docxPreviewRef.current) {
              docxPreviewRef.current.innerHTML = `
                <div style="padding: 20px; text-align: center;">
                  <p>Error rendering document preview for ${file.name}</p>
                  <p>${documentSource.type === 'cloud' ? 'Document URL' : 'Document path'}: ${file.path}</p>
                  <p>Please click the ${documentSource.type === 'cloud' ? 'Open in Browser' : 'Edit'} button to open the file.</p>
                </div>
              `;
            }
            console.error("Fatal error in document preview:", error);
            setIsDocLoading(false);
          }
        } else {
          // Ref not available yet, try again if we haven't exceeded max retries
          currentRetry++;

          // Use exponential backoff for increasing delay between retries
          const exponentialDelay = Math.min(baseRetryDelay * Math.pow(1.5, currentRetry), 4000);

          console.log(`docxPreviewRef.current ${!docxPreviewRef.current ? 'is null' : 'not in DOM'}. Retry attempt ${currentRetry}/${maxRetries} (delay: ${exponentialDelay}ms)`);

          if (currentRetry < maxRetries) {
            setTimeout(attemptPreviewRender, exponentialDelay);
          } else {
            console.error("Failed to render document preview: Element reference not available after multiple attempts");
            setIsDocLoading(false);

            // Attempt to create a fallback element if possible
            try {
              const previewArea = document.querySelector('.docx-preview-container') ||
                document.querySelector('.DocumentPreviewContainer');

              if (previewArea) {
                console.log("Found alternative preview container, attempting to render there");
                previewArea.innerHTML = `
                  <div style="padding: 2rem; text-align: center;">
                    <p>Failed to initialize document preview after multiple attempts.</p>
                    <p>Please try selecting the file again or refreshing the page.</p>
                    <button style="padding: 8px 16px; margin-top: 12px; cursor: pointer;" 
                            onclick="window.location.reload()">Refresh Page</button>
                  </div>
                `;
              }
            } catch (fallbackError) {
              console.error("Even fallback rendering failed:", fallbackError);
            }
          }
        }
      };

      // Delay initial attempt to ensure component has mounted
      setTimeout(attemptPreviewRender, 800); // Increased initial delay
    } catch (error) {
      console.error("Error in loadDocxPreview:", error);
      setIsDocLoading(false);
    }
  };  // Handle edit document or website based on selected preview tab
  const handleEditDocument = (file) => {
    if (previewTab === 'document') {
      // Open document in native application or browser for cloud docs
      if (file && file.path) {
        // Determine if this is a cloud-hosted document or local file
        const documentSource = getDocumentSource(file);

        if (documentSource.type === 'cloud') {
          // For cloud documents, open directly in browser
          console.log(`Opening cloud document URL: ${file.path}`);

          try {
            window.open(file.path, '_blank');
            console.log(`Opened cloud document in browser: ${file.path}`);
          } catch (e) {
            console.error('Failed to open cloud document:', e);
            alert(`Unable to open cloud document. URL: ${file.path}`);
          }
        } else if (file.name.toLowerCase().endsWith('.docx')) {
          // Special handling for local DOCX files - open in default DOCX editor
          console.log(`Opening local DOCX file at path: ${file.path}`);

          // For Windows systems, convert to proper file:/// URL format
          const fileUrl = 'file:///' + file.path.replace(/\//g, '\\');

          // Try to open the file using the browser's window.open
          // Note: This may be blocked by browser security in some environments
          try {
            window.open(fileUrl, '_blank');
            console.log(`Attempted to open: ${fileUrl}`);
          } catch (e) {
            console.error('Failed to open file:', e);
            alert(`Please open this file manually at location: ${file.path}`);
          }
        } else {
          // Handle other document types
          alert(`Opening file at path: ${file.path}`);
        }

        console.log('Opening file for editing:', file);
      } else {
        alert('No file selected or file path is missing.');
      }
    } else {
      // Open website URL in new browser tab
      if (projectData && projectData.url) {
        window.open(projectData.url, '_blank');
        console.log('Opening website in new browser tab:', projectData.url);
      } else {
        alert('No website URL available.');
      }
    }
  };  // Get file tree structure from documentHierarchy or fallback to generatedFiles
  const getFileTreeStructure = () => {
    // Initialize the base tree structure
    const tree = {};

    // If documentHierarchy data exists and has structure, use that
    if (documentHierarchy) {
      console.log("Using documentHierarchy for file tree:", documentHierarchy);

      // Case 1: New hierarchical structure with nested 'documents' and 'children'
      if (documentHierarchy.documents && typeof documentHierarchy.documents === 'object') {
        // Process nested structure recursively
        const processNestedStructure = (node, currentTree = tree) => {
          if (!node) return;

          // Handle folder nodes with children
          if (node.type === 'folder' || node.nodeType === 'folder') {
            const folderName = node.name;

            // Create folder in tree if it doesn't exist
            if (!currentTree[folderName]) {
              currentTree[folderName] = {
                name: folderName,
                type: 'folder',
                children: {}
              };
            }

            // Process children if they exist
            if (node.children) {
              // Handle children as object (key-value pairs)
              if (typeof node.children === 'object' && !Array.isArray(node.children)) {
                Object.entries(node.children).forEach(([childName, childNode]) => {
                  processNestedStructure(childNode, currentTree[folderName].children);
                });
              }
              // Handle children as array
              else if (Array.isArray(node.children)) {
                node.children.forEach(childItem => {
                 if (typeof childItem === 'object') {
                    processNestedStructure(childItem, currentTree[folderName].children);
                  }
                });
              }
            }
          }
          // Handle file nodes
          else if (node.type === 'file' || node.nodeType === 'file') {
            const fileName = node.name;
            const fileExt = fileName.split('.').pop().toLowerCase();

            currentTree[fileName] = {
              id: node.id || `doc-${Math.random().toString(36).substr(2, 9)}`,
              name: fileName,
              type: node.type || (fileExt === 'docx' ? 'docx' : fileExt),
              path: node.url || node.path || '',
              url: node.url || '',
              size: node.size || 0,
              lastModified: node.lastModified || new Date().toLocaleDateString(),
              fileType: 'file'
            };
          }
        };

        // Helper function to extract filename from URL
        // We're now using the document metadata from JSON directly
        // No need to extract filenames from URLs

        // Start processing from the root
        processNestedStructure(documentHierarchy.documents);
      }
      // Case 2: Legacy array format
      else if (Array.isArray(documentHierarchy)) {
        documentHierarchy.forEach(item => {
          // Process each item from the document hierarchy
          // Assuming item has name, type, path properties
          const filePath = item.path || item.relativePath || '';
          const normalizedPath = filePath.replace(/\\/g, '/');

          // Split path into components, removing any empty parts
          const pathParts = normalizedPath.split('/').filter(p => p.length > 0);
          let currentLevel = tree;

          // Navigate through the path
          for (let i = 0; i < pathParts.length - 1; i++) {
            const part = pathParts[i];
            if (!currentLevel[part]) {
              currentLevel[part] = {
                name: part,
                type: 'folder',
                children: {}
              };
            }
            currentLevel = currentLevel[part].children;
          }

          // Add the file
          if (pathParts.length > 0) {
            const fileName = pathParts[pathParts.length - 1];
            // Determine file type from extension if not provided in original data
            const fileExtension = fileName.split('.').pop().toLowerCase();
            const fileType = item.type || (fileExtension === 'docx' ? 'docx' : fileExtension);

            currentLevel[fileName] = {
              id: item.id || `doc-${Math.random().toString(36).substr(2, 9)}`,
              name: fileName,
              type: fileType,
              path: item.path || filePath,
              relativePath: item.relativePath || filePath,
              size: item.size || 0,
              lastModified: item.lastModified || new Date().toLocaleDateString(),
              fileType: 'file'
            };
          }
        });
      }
    }
    // Fallback to using projectData.generatedFiles if documentHierarchy is empty
    else if (projectData.generatedFiles && projectData.generatedFiles.length > 0) {
      console.log("Fallback to generatedFiles for file tree");

      projectData.generatedFiles.forEach(file => {
        // Fix file paths to handle both Windows and Unix-style paths
        const normalizedPath = file.relativePath ?
          file.relativePath.replace(/\\/g, '/') :
          file.path.replace(/\\/g, '/');

        // Split path into components, removing any empty parts
        const pathParts = normalizedPath.split('/').filter(p => p.length > 0);
        let currentLevel = tree;

        // Navigate through the path
        for (let i = 0; i < pathParts.length - 1; i++) {
          const part = pathParts[i];
          if (!currentLevel[part]) {
            currentLevel[part] = {
              name: part,
              type: 'folder',
              children: {}
            };
          }
          currentLevel = currentLevel[part].children;
        }

        // Add the file
        if (pathParts.length > 0) {
          const fileName = pathParts[pathParts.length - 1];
          // Determine file type from extension if not provided in original data
          const fileExtension = fileName.split('.').pop().toLowerCase();
          const fileType = file.type || (fileExtension === 'docx' ? 'docx' : fileExtension);

          currentLevel[fileName] = {
            ...file,
            name: fileName,
            type: fileType,
            fileType: 'file'
          };
        }
      });
    }

    console.log("Final file tree structure:", tree);
    return tree;
  };

  // Recursive function to render the file tree
  const renderFileTree = (tree) => {
    return Object.keys(tree).map(key => {
      const item = tree[key];
      // Check for folder using either type or fileType property
      // fileType is used in the modified structure, type is in the original data
      if (item.type === 'folder' || item.fileType === 'folder') {
        const isExpanded = isFolderExpanded(item.name);
        return (
          <TreeFolder key={item.name}>
            <TreeFolderHeader onClick={() => toggleFolder(item.name)}>
              <TreeFolderIcon>
                <FolderIcon />
              </TreeFolderIcon>
              <TreeFolderName>{item.name}</TreeFolderName>
            </TreeFolderHeader>
            {isExpanded && (
              <TreeFolderContent>
                {renderFileTree(item.children)}
              </TreeFolderContent>
            )}
          </TreeFolder>
        );
      } else {        // Get file icon based on file type or file extension
        const getFileIconByType = (item) => {
          // Check the explicit type property first
          if (item.type === 'docx') {
            return <DocxFileIcon />;
          }

          // If not found, check file extension from name
          const fileExt = item.name ? item.name.split('.').pop().toLowerCase() : '';
          if (fileExt === 'docx') {
            return <DocxFileIcon />;
          }

          // Default case
          return <DocxFileIcon />;
        };

        return (
          <TreeFile
            key={item.id}
            active={selectedFile && selectedFile.id === item.id}
            onClick={() => handleFileSelect(item)}
            title={item.path || item.name}
          >            <TreeFileIcon type={item.type || (item.name && item.name.endsWith('.docx') ? 'docx' : 'file')}>
              {getFileIconByType(item)}
            </TreeFileIcon>
            <TreeFileName>{item.name}</TreeFileName>
          </TreeFile>
        );
      }
    });
  };
  // Steps in the process
  const steps = [
    { number: 1, label: 'Design Analysis', completed: activeStep > 1 || activeStep === 1, active: activeStep === 1 },
    { number: 2, label: 'UI Component Mapping', completed: activeStep > 2, active: activeStep === 2 },
    { number: 3, label: 'Document & Preview', completed: activeStep > 3, active: activeStep === 3 },
    { number: 4, label: 'User Acceptance Testing', completed: activeStep > 4, active: activeStep === 4 },
    { number: 5, label: 'Deployment', completed: activeStep > 5, active: activeStep === 5 }
  ];

  // Handle action button click based on active step
  const handleActionClick = async () => {
    if (activeStep === 1) {
      // Handle Run Mapping action - post llmResponse to mapping API
      try {
        // Show loading toast
        // toast.showToast('Processing mapping data...', { type: 'info', autoClose: false });

        // Create sample llmResponse data for mapping
        // In a real implementation, this would come from LLM processing results
        const llmResponseData = analysisMetadata?.llm_response || [];

        // Post mapping data to API
        await ApiServiceEnhanced.postMappingData(projectId, llmResponseData);

        // Show success toast
        // toast.showToast('Mapping completed successfully!', { type: 'success' });

        // Move to next step
        setActiveStep(prevStep => prevStep + 1);
      } catch (error) {
        console.error('Error posting mapping data:', error);
        // toast.showToast(`Mapping failed: ${error.message}`, { type: 'error' });
      }
    } else if (activeStep === 2) {
      // Handle Generate Documentation action
      try {
        // Show loading toast
        // toast.showToast('Generating documentation...', { type: 'info', autoClose: false });

        // Call the generate-doc API with projectId
        setDocumentHierarchy(await ApiServiceEnhanced.generateDocumentation(projectId));

        // Show success toast
        // toast.showToast('Documentation generated successfully!', { type: 'success' });

        // Move to next step
        setActiveStep(prevStep => prevStep + 1);
      } catch (error) {
        console.error('Error generating documentation:', error);
        // toast.showToast(`Documentation generation failed: ${error.message}`, { type: 'error' });
      }
    } else if (activeStep < 5) {
      setActiveStep(prevStep => prevStep + 1);
    } else {
      // Final step - complete the project
      navigate('/dashboard');
    }
  };

  // Handle going back to the previous step
  const handleBackClick = () => {
    if (activeStep > 1) {
      setActiveStep(prevStep => prevStep - 1);
    }
  };

  // Pages data for search functionality
  const pageData = [
    {
      id: 'page-1',
      title: 'Home',
      path: '/',
      type: 'Landing Page',
      confidence: 'High',
      stats: { reused: 2, unused: 4, new: 0 }
    },
    {
      id: 'page-2',
      title: 'About Us',
      path: '/about',
      type: 'About Us Page',
      confidence: 'High',
      stats: { reused: 3, unused: 2, new: 1 }
    },
    {
      id: 'page-3',
      title: 'Services',
      path: '/services',
      type: 'Services Page',
      confidence: 'High',
      stats: { reused: 4, unused: 2, new: 1 }
    },
    {
      id: 'page-4',
      title: 'Contact Us',
      path: '/contact',
      type: 'Contact Page',
      confidence: 'High',
      stats: { reused: 1, unused: 3, new: 2 }
    },
    {
      id: 'page-5',
      title: 'Products',
      path: '/products',
      type: 'Products Catalog',
      confidence: 'Medium',
      stats: { reused: 5, unused: 2, new: 3 }
    }
  ];

  // Filter pages based on search query
  const filteredPages = pageData.filter(page =>
    page.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
    page.path.toLowerCase().includes(searchQuery.toLowerCase()) ||
    page.type.toLowerCase().includes(searchQuery.toLowerCase())
  );
  // Get button text based on active step
  const getButtonText = () => {
    switch (activeStep) {
      case 1: return 'Run Mapping';
      case 2: return 'Generate Documentation';
      case 3: return 'Start UAT Testing';
      case 4: return 'Deploy to Production';
      case 5: return 'Complete Project';
      default: return 'Next Step';
    }
  };

  // Get step title based on active step
  const getStepTitle = () => {
    switch (activeStep) {
      case 1: return '';
      case 2: return '';
      case 3: return 'Document & Website Preview';
      case 4: return 'User Acceptance Testing';
      case 5: return 'Deployment';
      default: return '';
    }
  };

  useEffect(() => {
    // Fetch kbMetadata and set loading state
    const fetchKbMetadata = async () => {
      try {
        const metadata = await ApiServiceEnhanced.getKBMetadata();
        setKbMetadata(metadata);
      } catch (error) {
        console.error('Error fetching kbMetadata:', error);
      } finally {
        setIsLoading(false); // Set loading to false after fetching
      }
    };

    fetchKbMetadata();
  }, []);

  useEffect(() => {
    if (activeStep === 1) {
      // Fetch analysisMetadata and set loading state
      const fetchAnalysisMetadata = async () => {
        try {
          const metadata = await ApiServiceEnhanced.getMetadata(project_details?.id);
          setAnalysisMetadata(metadata);
        } catch (error) {
          console.error('Error fetching analysisMetadata:', error);
        } finally {
          setIsAnalysisLoading(false); // Set loading to false after fetching
        }
      };

      fetchAnalysisMetadata();
    }
  }, [activeStep, project_details?.id]);

  useEffect(() => {
    if (activeStep === 2 && projectId) {
      // Start the timer
      const startTime = new Date();
      setApiStartTime(startTime);

      // Set up interval to update elapsed time every second
      const interval = setInterval(() => {
        const currentTime = new Date();
        const timeElapsed = Math.floor((currentTime - startTime) / 1000); // in seconds
        const minutes = Math.floor(timeElapsed / 60);
        const seconds = timeElapsed % 60;
        setElapsedTime(`${minutes}:${seconds < 10 ? '0' : ''}${seconds}`);
      }, 1000);

      setTimerInterval(interval);
      setIsAnalysisDataLoading(true);

      // Fetch project analysis data
      ApiServiceEnhanced.getProjectAnalysis(projectId)
        .then(data => {
          setProjectAnalysis(data);
          console.log('Project analysis data:', data);
        })
        .catch(err => {
          console.error('Failed to fetch project analysis:', err);
          setProjectAnalysis([]);
        })
        .finally(() => {
          setIsAnalysisDataLoading(false);
          // We keep the timer running to show total elapsed time
        });

      // Clean up the interval when component unmounts or step changes
      return () => {
        clearInterval(interval);
        setTimerInterval(null);
      };
    }
  }, [activeStep, projectId]);

  if (isLoading) {
    // Show a loading spinner or placeholder while waiting for kbMetadata
    return (
      <PageContainer>
        <DashboardSidebar onToggle={setSidebarCollapsed} />
        <MainContent sidebarCollapsed={sidebarCollapsed}>
          <Header>
            <PageTitle>Adobe Franklin</PageTitle>
          </Header>
          <ContentCard>
            <div style={{ textAlign: 'center', padding: '2rem' }}>
              <p>Loading...</p>
            </div>
          </ContentCard>
        </MainContent>
      </PageContainer>
    );
  }

  if (isAnalysisLoading) {
    // Show a loading spinner or placeholder while waiting for analysisMetadata
    return (
      <PageContainer>
        <DashboardSidebar onToggle={setSidebarCollapsed} />
        <MainContent sidebarCollapsed={sidebarCollapsed}>
          <Header>
            <PageTitle>Adobe Franklin</PageTitle>
          </Header>
          <ContentCard>
            <div style={{ textAlign: 'center', padding: '2rem' }}>
              <p>Loading analysis metadata...</p>
            </div>
          </ContentCard>
        </MainContent>
      </PageContainer>
    );
  }

  // Render content based on active step
  const renderStepContent = () => {
    switch (activeStep) {
      case 1: {
        return (
          <>
            <MetadataSection>
              <MetadataHeader>
                <SectionTitle>Template Metadata</SectionTitle>
                <CompleteBadge>
                  <CompleteIcon>
                    <CheckIcon />
                  </CompleteIcon>
                  Complete
                </CompleteBadge>
              </MetadataHeader>

              <MetadataGrid>
                <MetadataCard>
                  <MetadataLabel>Project Template</MetadataLabel>
                  <MetadataValue>{project_details?.project_metadata?.selected_template}</MetadataValue>
                </MetadataCard>

                <MetadataCard>
                  <MetadataLabel>Brand</MetadataLabel>
                  <MetadataValue>{kbMetadata.brand}</MetadataValue>
                </MetadataCard>

                <MetadataCard>
                  <MetadataLabel>Total Blocks</MetadataLabel>
                  <MetadataValue>{kbMetadata.total_count}</MetadataValue>
                </MetadataCard>

                <MetadataCard>
                  <MetadataLabel>Global Blocks</MetadataLabel>
                  <MetadataValue>{kbMetadata.global_count}</MetadataValue>
                </MetadataCard>

                <MetadataCard>
                  <MetadataLabel>Site Building Blocks</MetadataLabel>
                  <MetadataValue>{kbMetadata.page_building_count}</MetadataValue>
                </MetadataCard>
              </MetadataGrid>
            </MetadataSection>
            <MetadataSection>              <MetadataHeader>
              <SectionTitle>Design Metadata</SectionTitle>
              <CompleteBadge>
                <CompleteIcon>
                  <CheckIcon />
                </CompleteIcon>
                Complete
              </CompleteBadge>
            </MetadataHeader>

              <div>{analysisMetadata?.progress}</div>

              <StatsGrid>
                <StatCard>
                  <StatValue>{analysisMetadata?.pages}</StatValue>
                  <StatLabel>Pages</StatLabel>
                </StatCard>

                <StatCard>
                  <StatValue>{analysisMetadata?.links}</StatValue>
                  <StatLabel>links</StatLabel>
                </StatCard>

                <StatCard>
                  <StatValue>{analysisMetadata?.images}</StatValue>
                  <StatLabel>Images</StatLabel>
                </StatCard>

                <StatCard>
                  <StatValue>{analysisMetadata?.blocks}</StatValue>
                  <StatLabel>blocks</StatLabel>
                </StatCard>

                <StatCard>
                  <StatValue>{analysisMetadata?.forms}</StatValue>
                  <StatLabel>forms</StatLabel>
                </StatCard>

                <StatCard>
                  <StatValue> 1 </StatValue>
                  <StatLabel>videos</StatLabel>
                </StatCard>
              </StatsGrid>
            </MetadataSection>

            {/* Display uploaded files if any */}
            {uploadedFiles && uploadedFiles.length > 0 && (
              <UploadedFilesSection>
                <FilesHeader>
                  <FilesTitle>Uploaded Files</FilesTitle>
                </FilesHeader>
                <FilesGrid>
                  {uploadedFiles.map((file, index) => {
                    // Check if file is an image by extension
                    const imageExtensions = ['png', 'jpg', 'jpeg', 'gif', 'bmp', 'webp'];
                    const ext = file.extension || (file.name ? file.name.split('.').pop().toLowerCase() : '');
                    const isImage = imageExtensions.includes(ext);
                    return (
                      <FileCard key={`file-${index}`}>
                        {isImage && file.previewUrl ? (
                          <FileImagePreview>
                            <img src={file.previewUrl} alt={file.name} />
                          </FileImagePreview>
                        ) : (
                          <FileIconPreview backgroundColor={getFileColor(ext)}>
                            {getFileIcon(ext)}
                          </FileIconPreview>
                        )}
                        <FileInfo>
                          <FileName title={file.name}>
                            {file.name.length > 20 ? file.name.substring(0, 17) + '...' : file.name}
                          </FileName>
                          <FileSize>{formatFileSize(file.size)}</FileSize>
                        </FileInfo>
                      </FileCard>
                    );
                  })}
                </FilesGrid>
              </UploadedFilesSection>
            )}
          </>
        );
      }
      case 2:
        return (
          <MetadataSection>
            <MetadataHeader style={{ justifyContent: 'space-between', marginBottom: '.5rem' }}>
              <SectionTitle style={{ color: theme.colors.textSecondary, fontSize: '95%' }}>Review and Migrate</SectionTitle>
            </MetadataHeader>
            <MetadataSection>
              <div style={{ marginBottom: '1rem' }}>
                <StepTitle>{projectData.url}</StepTitle>
              </div>
            </MetadataSection>

            <MetadataSection>
              <MetadataHeader style={{ justifyContent: 'space-between' }}>
                <div style={{ display: 'flex', gap: '1.5rem', justifyContent: 'space-between', alignItems: 'center' }}>
                  <SectionTitle>Mapping Summary</SectionTitle>

                  <MetadataCard style={{ padding: '.50rem', background: 'transparent', border: 'none' }}>
                    <MetadataLabel>Design System</MetadataLabel>
                    <MetadataValue>aem-block-collection</MetadataValue>
                  </MetadataCard>

                  <MetadataCard style={{ padding: '.50rem', background: 'transparent', border: 'none' }}>
                    <MetadataLabel>Site Template</MetadataLabel>
                    <MetadataValue>{projectData.brand}</MetadataValue>
                  </MetadataCard>
                </div>
                <SecondaryButton onClick={() => console.log('Regenerate clicked')} style={{ fontSize: '0.9rem' }}>
                  Regenerate All Pages
                </SecondaryButton>
              </MetadataHeader>

              <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: '1.5rem', marginBottom: '2rem' }}>
                <MetadataCard style={{ padding: '1.25rem' }}>
                  <MetadataValue style={{ color: theme.colors.primary, fontWeight: 'bold', fontSize: '1.2rem' }}>100%</MetadataValue>
                  <MetadataLabel>Mapping Status</MetadataLabel>
                </MetadataCard>

                <MetadataCard style={{ padding: '1.25rem' }}>
                  <MetadataValue style={{ fontWeight: 'bold', fontSize: '1.2rem' }}>
                    {projectAnalysis.length}/{projectAnalysis.length}
                  </MetadataValue>
                  <MetadataLabel>Pages Completed</MetadataLabel>
                </MetadataCard>

                <MetadataCard style={{ padding: '1.25rem' }}>
                  <MetadataValue style={{ fontWeight: 'bold', fontSize: '1.2rem' }}>{elapsedTime}</MetadataValue>
                  <MetadataLabel>Elapsed Time</MetadataLabel>
                </MetadataCard>

                <MetadataCard style={{ padding: '1.25rem' }}>
                  <MetadataValue style={{ fontWeight: 'bold', fontSize: '1.2rem' }}>0</MetadataValue>
                  <MetadataLabel>Content Changes</MetadataLabel>
                </MetadataCard>
              </div>

              <div style={{ backgroundColor: theme.colors.cardBackground, border: `1px solid ${theme.colors.border}`, borderRadius: '8px', overflow: 'hidden' }}>
                <div style={{ padding: '1.25rem', borderBottom: `1px solid ${theme.colors.border}`, backgroundColor: theme.colors.inputBackground }}>
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                    <div style={{ fontWeight: '500' }}>Page Status</div>
                  </div>
                </div>

                {isAnalysisDataLoading ? (
                  <div style={{ padding: '2rem', textAlign: 'center' }}>
                    <p>Loading analysis data...</p>
                  </div>
                ) : (
                  <PageCardsGrid>
                    {projectAnalysis.length > 0 ? (
                      projectAnalysis.map((analysis, index) => {
                        // Extract page title from llm_response if possible
                        let pageTitle = "Page";
                        let pageType = "Content Page";

                        if (analysis.llm_response) {
                          try {
                            const parsedResponse = JSON.parse(analysis.llm_response);
                            pageTitle = parsedResponse.page_title || `Page ${index + 1}`;
                            pageType = "Content Page";
                          } catch (e) {
                            console.error("Error parsing llm_response:", e);
                          }
                        }

                        return (
                          <PageCard key={analysis.id}>
                            <PageCardImagePreview>
                              <div style={{
                                width: '100%',
                                height: '100%',
                                background: `linear-gradient(135deg, ${theme.colors.primaryLight}, ${theme.colors.primary})`,
                                display: 'flex',
                                flexDirection: 'column',
                                alignItems: 'center',
                                justifyContent: 'center',
                                color: 'white'
                              }}>
                                <div style={{ fontSize: '1.25rem', fontWeight: '600', marginBottom: '0.5rem' }}>
                                  {pageTitle}
                                </div>
                                <div style={{ fontSize: '0.85rem', opacity: '0.8' }}>{pageType}</div>
                              </div>

                              <PageCardStatusBadge>
                                <CheckIcon />
                              </PageCardStatusBadge>
                            </PageCardImagePreview>

                            <PageCardInfo>
                              <PageCardHeader>
                                <div>
                                  <PageCardTitle>{pageTitle}</PageCardTitle>
                                  <PageCardPath>
                                    {pageTitle ?
                                      `/${pageTitle.toLowerCase().replace(/\s+/g, '-').replace(/[^a-z0-9-]/g, '')}` :
                                      `/${analysis.filename.split('.')[0].toLowerCase()}`}
                                  </PageCardPath>
                                </div>
                                <PageCardConfidence>
                                  High
                                </PageCardConfidence>
                              </PageCardHeader>

                              <PageCardStats>
                                <PageCardStat>
                                  <PageCardStatValue>{analysis.llm_analysis?.reusable_components || 0}</PageCardStatValue>
                                  <PageCardStatLabel>Sitewide component</PageCardStatLabel>
                                </PageCardStat>

                                <PageCardStat>
                                  <PageCardStatValue>{analysis.llm_analysis?.total_components || 0}</PageCardStatValue>
                                  <PageCardStatLabel>Total components</PageCardStatLabel>
                                </PageCardStat>

                                {/* <PageCardStat>
                                  <PageCardStatValue>0</PageCardStatValue>
                                  <PageCardStatLabel>new</PageCardStatLabel>
                                </PageCardStat> */}
                              </PageCardStats>

                              <PageCardFooter>
                                <SecondaryButton style={{ padding: '0.5rem 0.75rem', fontSize: '0.85rem' }}>
                                  Edit
                                </SecondaryButton>
                                <SecondaryButton style={{ padding: '0.5rem 0.75rem', fontSize: '0.85rem' }}>
                                  Remove
                                </SecondaryButton>
                              </PageCardFooter>
                            </PageCardInfo>
                          </PageCard>
                        );
                      })
                    ) : (
                      <div style={{ padding: '2rem', textAlign: 'center' }}>
                        <p>No analysis data available for this project.</p>
                      </div>
                    )}
                  </PageCardsGrid>
                )}
              </div>
            </MetadataSection>
          </MetadataSection>
        );
      case 3:
        return (
          <MetadataSection>
            <MetadataHeader>
              <SectionTitle>Generated Documents & Preview</SectionTitle>
            </MetadataHeader>

            <MetadataGrid style={{ marginBottom: '1.5rem' }}>
              <MetadataCard>
                <MetadataLabel>Generation Status</MetadataLabel>
                <MetadataValue style={{ color: theme.colors.success }}>Complete</MetadataValue>
              </MetadataCard>

              <MetadataCard>
                <MetadataLabel>Documents Generated</MetadataLabel>
                <MetadataValue>{projectData.generatedFiles.length}</MetadataValue>
              </MetadataCard>

              <MetadataCard>
                <MetadataLabel>Last Generated</MetadataLabel>
                <MetadataValue>
                  {new Date().toLocaleDateString('en-US', {
                    month: 'short',
                    day: 'numeric',
                    year: 'numeric',
                    hour: 'numeric',
                    minute: '2-digit',
                    hour12: true
                  })}
                </MetadataValue>
              </MetadataCard>
            </MetadataGrid>

            <FileExplorerContainer>
              {/* File tree sidebar */}
              <FileTreeContainer>
                <FileTreeHeader>
                  <div>Project Files</div>
                </FileTreeHeader>
                <FileTreeContent>
                  {renderFileTree(getFileTreeStructure())}
                </FileTreeContent>
              </FileTreeContainer>

              {/* Preview content */}              <PreviewContentContainer>                <PreviewNavTabs>
                <div style={{ display: 'flex', alignItems: 'center' }}>
                  <PreviewNavTab
                    active={previewTab === 'document'}
                    onClick={() => setPreviewTab('document')}
                  >
                    Document Preview
                  </PreviewNavTab>
                  <PreviewNavTab
                    active={previewTab === 'web'}
                    onClick={() => setPreviewTab('web')}
                  >
                    Web Preview
                  </PreviewNavTab>
                </div>
                {(selectedFile || previewTab === 'web') && (
                  <button
                    onClick={() => handleEditDocument(selectedFile)}
                    style={{
                      backgroundColor: 'transparent',
                      border: `1px solid ${theme.colors.border}`,
                      borderRadius: '4px',
                      padding: '6px 12px',
                      fontSize: '0.9rem',
                      marginLeft: 'auto',
                      display: 'flex',
                      alignItems: 'center',
                      gap: '0.5rem',
                      cursor: 'pointer',
                      color: theme.colors.text
                    }}
                  >
                    {previewTab === 'document' ? (
                      // Edit icon for document preview
                      <svg width="14" height="14" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path d="M20.71 7.04c.39-.39.39-1.02 0-1.41l-2.34-2.34c-.39-.39-1.02-.39-1.41 0l-1.84 1.83 3.75 3.75 1.84-1.83zM3 17.25V21h3.75L17.81 9.93l-3.75-3.75L3 17.25z" fill="currentColor" />
                      </svg>
                    ) : (
                      // External link icon for web preview
                      <svg width="14" height="14" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
                        <path d="M15 3h6v6" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
                        <path d="M10 14L21 3" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
                      </svg>
                    )}
                    {previewTab === 'document' ? 'Edit' : 'Open in Browser'}
                  </button>
                )}
              </PreviewNavTabs>
                <PreviewContent>
                  {previewTab === 'document' ? (
                    selectedFile ? (
                      <>
                        {isDocLoading ? (
                          <div style={{
                            height: '100%',
                            display: 'flex',
                            alignItems: 'center',
                            justifyContent: 'center',
                            flexDirection: 'column'
                          }}>
                            <div style={{ marginBottom: '1rem' }}>
                              <svg
                                width="40"
                                height="40"
                                viewBox="0 0 24 24"
                                xmlns="http://www.w3.org/2000/svg"
                                style={{
                                  animation: 'spin 2s linear infinite',
                                  color: theme.colors.primary
                                }}
                              >
                                <style>{`
                                  @keyframes spin {
                                    0% { transform: rotate(0deg); }
                                    100% { transform: rotate(360deg); }
                                  }
                                `}</style>
                                <circle
                                  cx="12"
                                  cy="12"
                                  r="10"
                                  stroke="currentColor"
                                  strokeWidth="2"
                                  fill="none"
                                  opacity="0.25"
                                />
                                <path
                                  d="M12 2C6.48 2 2 6.48 2 12"
                                  stroke="currentColor"
                                  strokeWidth="3"
                                  strokeLinecap="round"
                                  fill="none"
                                />
                              </svg>
                            </div>
                            <div>Loading document preview...</div>
                          </div>
                        ) : (<div
                          style={{
                            height: '100%',
                            overflow: 'auto',
                            padding: '1rem'
                          }}
                        >                            {/* Document information banner */}
                          <div style={{
                            marginBottom: '1rem',
                            display: 'flex',
                            justifyContent: 'space-between',
                            alignItems: 'center',
                            padding: '0.5rem 1rem',
                            backgroundColor: theme.colors.cardBackground,
                            borderRadius: '4px',
                            border: `1px solid ${theme.colors.border}`
                          }}>
                            <div style={{ flex: 1 }}>
                              <strong>{selectedFile.name}</strong>
                              <div style={{
                                fontSize: '0.8rem',
                                color: theme.colors.textSecondary,
                                overflow: 'hidden',
                                textOverflow: 'ellipsis',
                                whiteSpace: 'nowrap',
                                maxWidth: '500px'
                              }}>
                                Path: {selectedFile.path}
                              </div>
                              <div style={{ fontSize: '0.8rem', color: theme.colors.textSecondary }}>
                                Last modified: {selectedFile.lastModified}
                              </div>
                            </div>
                            <span style={{
                              fontSize: '0.8rem',
                              backgroundColor: theme.colors.primaryLight,
                              color: theme.colors.primary,
                              padding: '0.25rem 0.5rem',
                              borderRadius: '4px',
                              whiteSpace: 'nowrap'
                            }}>
                              DOCX Preview
                            </span>
                          </div>                              {/* DOCX preview container - the docx-preview plugin will render content here */}
                          <DocumentPreviewContainer
                            data-testid="docx-container-wrapper"
                            id="docx-container-wrapper"
                          >
                            <div
                              ref={docxPreviewRef}
                              className="docx-preview-container"
                              id="docx-preview-container"
                              style={{
                                width: '100%',
                                minHeight: '800px',
                                backgroundColor: 'white',
                                borderRadius: '4px',
                                overflow: 'auto',
                                padding: '10px',
                                visibility: 'visible' // Ensure visibility
                              }}
                              data-file-path={selectedFile.path}
                              data-file-type={selectedFile.type || (selectedFile.name && selectedFile.name.toLowerCase().endsWith('.docx') ? 'docx' : 'unknown')}
                              data-ready="true" // Add a marker to indicate the element is ready
                            >
                              {/* The docx-preview plugin will inject content here */}
                              {/* Initial placeholder content to ensure the element has size */}
                              <div style={{
                                padding: '1rem',
                                textAlign: 'center',
                                color: '#888'
                              }}>
                                Initializing document preview...
                              </div>
                            </div>
                          </DocumentPreviewContainer>
                        </div>
                        )}
                      </>
                    ) : (
                      <div style={{ padding: '2rem', textAlign: 'center' }}>
                        <p>Select a document from the file explorer to preview.</p>
                      </div>
                    )
                  ) : (
                    <div style={{ height: '100%' }}>
                      <PreviewContainer style={{ margin: 0, height: '100%', border: 'none', borderRadius: 0 }}>
                        <PreviewHeader>
                          <div style={{ flex: 1 }}>
                            <span style={{ marginRight: '10px' }}>Preview:</span>
                            <strong>{projectData.url}</strong>
                          </div>
                        </PreviewHeader>
                        <PreviewFrame>
                          {projectData.url && (
                            <WebsiteIframe
                              src={projectData.url}
                              title="AEM Franklin Site Preview"
                              sandbox="allow-same-origin allow-scripts allow-popups allow-forms"
                              onLoad={(e) => console.log('Website preview loaded')}
                              onError={(e) => console.error('Error loading website preview', e)}
                            />
                          )}
                          <div
                            style={{
                              display: !projectData.url ? 'flex' : 'none',
                              flexDirection: 'column',
                              alignItems: 'center',
                              justifyContent: 'center',
                              textAlign: 'center',
                              width: '100%',
                              height: '100%'
                            }}
                          >
                            <img
                              src="/logos/adobe-logo.svg"
                              alt="Adobe Logo"
                              style={{ width: '60px', marginBottom: '1rem', opacity: 0.6 }}
                            />
                            <h3>Website Preview</h3>
                            <p>Preview of your AEM Franklin site would display here</p>
                          </div>
                        </PreviewFrame>
                      </PreviewContainer>
                    </div>
                  )}
                </PreviewContent>
              </PreviewContentContainer>            </FileExplorerContainer>
          </MetadataSection>
        );
      case 4:
        // Repurposing case 4 for UAT Testing since we combined steps 3 and 4
        return (
          <TestingContainer>
            <MetadataHeader>
              <SectionTitle>User Acceptance Testing</SectionTitle>
            </MetadataHeader>

            <p>Track and manage user acceptance tests for the AEM Franklin project:</p>

            <TestingGrid>
              {projectData.userAcceptanceTests.map(test => (
                <TestingCard key={test.id}>
                  <TestingCardHeader>
                    <TestingTitle>{test.name}</TestingTitle>
                    <TestingStatus status={test.status}>{test.status}</TestingStatus>
                  </TestingCardHeader>
                  <TestingDescription>{test.description}</TestingDescription>
                  <TestingDetails>
                    <p><strong>Tester:</strong> {test.tester}</p>
                    <p><strong>Date:</strong> {test.date}</p>
                    <p><strong>Notes:</strong> {test.notes}</p>
                  </TestingDetails>
                </TestingCard>
              ))}
            </TestingGrid>

            <MetadataHeader>
              <SectionTitle>Test Summary</SectionTitle>
            </MetadataHeader>

            <MetadataGrid>
              <MetadataCard>
                <MetadataLabel>Total Tests</MetadataLabel>
                <MetadataValue>{projectData.userAcceptanceTests.length}</MetadataValue>
              </MetadataCard>
              <MetadataCard>
                <MetadataLabel>Passed</MetadataLabel>
                <MetadataValue style={{ color: theme.colors.success }}>
                  {projectData.userAcceptanceTests.filter(t => t.status === 'Passed').length}
                </MetadataValue>
              </MetadataCard>
              <MetadataCard>
                <MetadataLabel>Failed</MetadataLabel>
                <MetadataValue style={{ color: theme.colors.error }}>
                  {projectData.userAcceptanceTests.filter(t => t.status === 'Failed').length}
                </MetadataValue>
              </MetadataCard>
              <MetadataCard>
                <MetadataLabel>In Progress</MetadataLabel>
                <MetadataValue style={{ color: theme.colors.warning }}>
                  {projectData.userAcceptanceTests.filter(t => t.status === 'In Progress').length}
                </MetadataValue>
              </MetadataCard>
            </MetadataGrid>
          </TestingContainer>
        ); case 5:
        return (
          <DeploymentContainer>
            <MetadataHeader>
              <SectionTitle>Deployment Pipeline</SectionTitle>
            </MetadataHeader>

            <DeploymentSteps>
              {projectData.deploymentStages.map((stage, index) => (
                <DeploymentStep key={stage.id}>
                  <StepIcon status={stage.status}>
                    {stage.status === 'completed' ? (
                      <CheckIcon />
                    ) : stage.status === 'in-progress' ? (
                      <ClockIcon />
                    ) : (
                      index + 1
                    )}
                  </StepIcon>
                  <StepContent>
                    <StepContentHeader>
                      <StepName>{stage.name}</StepName>
                      <StepTime>{stage.time}</StepTime>
                    </StepContentHeader>
                    <div style={{ fontSize: '0.9rem', color: theme.colors.textSecondary }}>
                      {stage.description}
                    </div>
                  </StepContent>
                </DeploymentStep>
              ))}
            </DeploymentSteps>

            <MetadataHeader>
              <SectionTitle>Environments</SectionTitle>
            </MetadataHeader>

            <EnvironmentContainer>
              {projectData.environments.map(env => (
                <EnvironmentCard key={env.name}>
                  <h5>
                    <ServerIcon style={{ marginRight: '0.5rem', position: 'relative', top: '4px' }} />
                    {env.name}
                    <span
                      style={{
                        display: 'inline-block',
                        width: '8px',
                        height: '8px',
                        borderRadius: '50%',
                        marginLeft: '0.5rem',
                        backgroundColor:
                          env.status === 'Online' ? theme.colors.success :
                            env.status === 'Deploying' ? theme.colors.warning :
                              theme.colors.textSecondary
                      }}
                    />
                  </h5>
                  <div style={{ fontSize: '0.9rem', marginBottom: '0.5rem' }}>
                    <a href={env.url} style={{ color: theme.colors.primary, textDecoration: 'none' }}>
                      {env.url}
                    </a>
                  </div>
                  <div style={{ fontSize: '0.85rem', color: theme.colors.textSecondary }}>
                    <div>Status: {env.status}</div>
                    <div>Last Deployment: {env.lastDeployed}</div>
                  </div>
                </EnvironmentCard>
              ))}
            </EnvironmentContainer>
          </DeploymentContainer>
        );
      default:
        return null;
    }
  };

  return (
    <PageContainer>
      <DashboardSidebar onToggle={handleSidebarToggle} />
      <MainContent sidebarCollapsed={sidebarCollapsed}>
        <Header>
          <PageTitle>Adobe Franklin</PageTitle>
        </Header>

        <StepperContainer>
          {steps.map((step, index) => (
            <React.Fragment key={step.number}>
              <Step>
                <StepNumber active={step.active} completed={step.completed}>
                  {step.completed ? <CheckIcon /> : step.number}
                </StepNumber>
                <StepLabel active={step.active}>{step.label}</StepLabel>
              </Step>
              {index < steps.length - 1 && (
                <StepConnector completed={step.completed} />
              )}
            </React.Fragment>
          ))}
        </StepperContainer>

        <ContentCard>
          {activeStep === 1 && (
            <CardTitle>{projectData.name}</CardTitle>
          )}
          {activeStep !== 2 && (
            <StepTitle>{getStepTitle()}</StepTitle>
          )}
          {renderStepContent()}

          <ActionContainer>
            <CancelButton onClick={() => navigate('/dashboard')}>Cancel</CancelButton>

            {activeStep > 1 && (
              <BackButton onClick={handleBackClick}>
                <span style={{ display: 'flex', alignItems: 'center' }}>
                  <ArrowLeftIcon />
                  Back
                </span>
              </BackButton>
            )}

            <PrimaryButton onClick={handleActionClick}>{getButtonText()}</PrimaryButton>
          </ActionContainer>
        </ContentCard>
      </MainContent>
    </PageContainer>
  );
};

export default AdobeFranklinProject;