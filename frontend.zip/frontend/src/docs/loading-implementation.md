# Component-Level Loading Implementation

This document explains the new loading state management in the aibuilder frontend.

## Overview

We've replaced the global loading overlay with a component-level loading approach that:

1. Allows users to continue interacting with the UI during API calls
2. Shows targeted loading state indicators where needed
3. Provides multiple options for indicating loading states
4. Uses a non-blocking global indicator for API operations

## Components

### LoadingStates.js
Reusable loading components for different contexts:

- Spinners for inline loading
- Section loaders for content areas
- Skeleton loaders for content placeholders
- Loading button states

### GlobalLoadingIndicator.js
A subtle progress bar at the top of the screen that appears during API calls.

### LoadingStatus.js
A non-intrusive status indicator that appears in the bottom-right corner for operations taking longer than 500ms.

## Hooks

### useApiLoading.js
A React hook to track loading state of API requests:

```jsx
const { isLoading, activeCount, activeRequests } = useApiLoading();
```

### useApiRequest.js
A custom hook for handling API requests with loading states:

```jsx
const { 
  isLoading, 
  error, 
  data, 
  execute 
} = useApiRequest(apiFunction, options);
```

## API Client

### apiClient.js
An enhanced Axios client with automatic loading state tracking:

- Tracks requests via interceptors
- Exposes loading state events and listeners
- Manages loading state without blocking UI

## Usage Examples

### Basic loading state in a component:
```jsx
const { isLoading } = useApiLoading();

return (
  <div>
    {isLoading ? <Spinner /> : 'Content loaded!'}
  </div>
);
```

### Component with API request:
```jsx
const { isLoading, error, data, execute } = useApiRequest(
  () => ApiServiceEnhanced.getData(),
  {
    onSuccess: (data) => showSuccessToast('Data loaded!'),
    onError: (err) => showErrorToast(err.message)
  }
);

// Show appropriate UI based on state
if (isLoading) return <SectionLoader />;
if (error) return <ErrorMessage>{error}</ErrorMessage>;
if (!data) return <EmptyState />;

return <DataTable data={data} />;
```

## Migration

To migrate an existing component:

1. Import the enhanced API service:
   ```jsx
   import ApiServiceEnhanced from '../services/ApiServiceEnhanced';
   ```

2. Replace ApiService calls with ApiServiceEnhanced:
   ```jsx
   const data = await ApiServiceEnhanced.getData();
   ```

3. Use appropriate loading components:
   ```jsx
   {isLoading ? <SectionLoader /> : <DataDisplay data={data} />}
   ```

4. For more granular control, use the useApiLoading hook:
   ```jsx
   const { isLoading, activeRequests } = useApiLoading();
   ```

## Best Practices

1. Use skeleton loaders for content-heavy components
2. Use spinners for quick operations
3. Provide feedback on the component that triggered the operation
4. Avoid blocking the entire UI during API calls
5. Use toast notifications for operation results
