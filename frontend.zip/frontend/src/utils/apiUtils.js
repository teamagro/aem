// apiUtils.js
import { useState, useCallback } from 'react';

/**
 * Custom hook for handling API requests with loading states
 * 
 * @param {Function} apiFunction - The API function to call
 * @param {Object} options - Configuration options
 * @returns {Object} - API request handler and state
 */
export const useApiRequest = (apiFunction, options = {}) => {
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState(null);
  const [data, setData] = useState(null);
  const [retryCount, setRetryCount] = useState(0);
  
  // Default options
  const defaultOptions = {
    onSuccess: () => {},
    onError: () => {},
    immediate: false,
    initialData: null,
    maxRetries: 3
  };
  
  // Merge defaults with provided options
  const config = { ...defaultOptions, ...options };
  
  // If initial data is provided, set it
  if (config.initialData && !data) {
    setData(config.initialData);
  }
  
  // Execute the API request with retry handling
  const execute = useCallback(async (...args) => {
    try {
      setIsLoading(true);
      setError(null);
      setRetryCount(0);
      
      const result = await apiFunction(...args);
      
      setData(result);
      config.onSuccess(result);
      return result;
    } catch (err) {
      // Check if we should retry based on config and error type
      const shouldRetry = config.shouldRetry 
        ? config.shouldRetry(err) 
        : (err?.response?.status >= 500 || err?.response?.status === 429) && retryCount < config.maxRetries;
      
      if (shouldRetry) {
        // Update retry count
        const newRetryCount = retryCount + 1;
        setRetryCount(newRetryCount);
        
        if (newRetryCount <= config.maxRetries) {
          // Calculate backoff delay
          const delay = Math.pow(2, newRetryCount) * (config.retryDelay || 300);
          
          console.log(`Retrying request (${newRetryCount}/${config.maxRetries}) after ${delay}ms...`);
          
          // Wait before retrying
          await new Promise(resolve => setTimeout(resolve, delay));
          
          // Recursive call to execute
          return execute(...args);
        }
      }
      
      // If we've exhausted our retries or shouldn't retry, set error state
      setError(err.message || 'An error occurred');
      config.onError(err);
      return null;
    } finally {
      setIsLoading(false);
    }
  }, [apiFunction, config, retryCount]);
  
  // If immediate execution is requested, call execute() when hook is initialized
  if (config.immediate && !isLoading && !data && !error) {
    execute();
  }
  
  return {
    execute,
    isLoading,
    error,
    data,
    setData
  };
};

/**
 * Create optimistic update handler for API requests
 * 
 * @param {Function} setData - State setter function
 * @param {Function} updateFn - Function to transform data for optimistic update
 * @param {Function} apiCall - The API function to call
 * @returns {Function} - Handler function
 */
export const createOptimisticHandler = (setData, updateFn, apiCall) => {
  return async (...args) => {
    // Store the previous data to restore if the API call fails
    const previousData = setData(current => updateFn(current, ...args));
    
    try {
      // Make the actual API call
      const result = await apiCall(...args);
      return result;
    } catch (error) {
      // If the API call fails, revert to the previous data
      setData(previousData);
      throw error;
    }
  };
};

/**
 * Track active API requests
 */
const activeRequests = new Map();

/**
 * Request queue manager
 */
export const requestQueue = {
  /**
   * Add a request to the queue
   * @param {string} key - Unique identifier for the request
   * @param {Promise} promise - The request promise
   * @returns {Promise} - The original promise
   */
  add(key, promise) {
    activeRequests.set(key, promise);
    
    // Remove from the queue when completed
    promise.finally(() => {
      if (activeRequests.get(key) === promise) {
        activeRequests.delete(key);
      }
    });
    
    return promise;
  },
  
  /**
   * Check if a request is in progress
   * @param {string} key - Unique identifier for the request
   * @returns {boolean} - True if request is in progress
   */
  isLoading(key) {
    return activeRequests.has(key);
  },
  
  /**
   * Cancel a pending request
   * @param {string} key - Unique identifier for the request
   */
  cancel(key) {
    activeRequests.delete(key);
  },
  
  /**
   * Get the number of active requests
   * @returns {number} - Count of active requests
   */
  getActiveCount() {
    return activeRequests.size;
  }
};
