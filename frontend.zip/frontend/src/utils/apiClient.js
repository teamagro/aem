import axios from 'axios';
import config from '../config/config';

/**
 * Create an API client with automatic loading state handling
 * This approach allows managing loading states more granularly without a global overlay
 */
const createApiClient = () => {
  // Create axios instance
  const api = axios.create({
    baseURL: config.API_BASE_URL,
    headers: {
      'Content-Type': 'application/json'
    }
  });
  
  // Retry configuration
  const MAX_RETRIES = 3;
  
  // Create and store the current cancel token
  let currentCancelToken = null;
  
  /**
   * Creates a new cancel token and cancels any existing token
   * @returns {CancelToken} - New axios cancel token
   */
  const createCancelToken = () => {
    // Cancel previous token if it exists
    if (currentCancelToken) {
      currentCancelToken.cancel('Operation canceled by navigation');
    }
    
    // Create new token
    currentCancelToken = axios.CancelToken.source();
    return currentCancelToken.token;
  };
  
  // Active requests tracker
  const activeRequests = new Map();
  
  // Event listeners for loading state changes
  const loadingStartListeners = new Set();
  const loadingEndListeners = new Set();
  
  // Register loading state change listeners
  const onLoadingStart = (callback) => loadingStartListeners.add(callback);
  const onLoadingEnd = (callback) => loadingEndListeners.add(callback);
  const offLoadingStart = (callback) => loadingStartListeners.delete(callback);
  const offLoadingEnd = (callback) => loadingEndListeners.delete(callback);
  
  // Track requests with custom ID
  const trackRequest = (requestId) => {
    return {
      started: () => {
        activeRequests.set(requestId, true);
        loadingStartListeners.forEach(listener => listener(requestId));
      },
      ended: () => {
        activeRequests.delete(requestId);
        loadingEndListeners.forEach(listener => listener(requestId));
      }
    };
  };

  // Request interceptor to handle loading state
  api.interceptors.request.use(
    config => {
      // Generate a request ID if not provided
      const requestId = config.requestId || `${config.method}-${config.url}-${Date.now()}`;
      config.requestId = requestId;
      
      // Start loading only if not specified to skip
      if (!config.skipLoadingIndicator) {
        trackRequest(requestId).started();
      }
      
      return config;
    },
    error => {
      return Promise.reject(error);
    }
  );
  
  // Response interceptor to handle loading state
  api.interceptors.response.use(
    response => {
      // End loading for this request
      const { config } = response;
      if (config && config.requestId && !config.skipLoadingIndicator) {
        trackRequest(config.requestId).ended();
      }
      
      return response;
    },
    error => {
      const originalRequest = error.config;
      
      // End loading on error
      if (originalRequest && originalRequest.requestId && !originalRequest.skipLoadingIndicator) {
        trackRequest(originalRequest.requestId).ended();
      }
      
      // Implement retry logic with max retries
      if (error.response && (error.response.status === 429 || error.response.status >= 500) && 
          originalRequest && 
          (!originalRequest._retry || originalRequest._retry < MAX_RETRIES)) {
        
        // Initialize or increment retry counter
        originalRequest._retry = (originalRequest._retry || 0) + 1;
        
        // Add exponential backoff delay
        const delay = Math.pow(2, originalRequest._retry) * 300;
        
        console.log(`Retrying request (${originalRequest._retry}/${MAX_RETRIES}) after ${delay}ms...`);
        
        return new Promise(resolve => {
          setTimeout(() => {
            resolve(api(originalRequest));
          }, delay);
        });
      }
      
      return Promise.reject(error);
    }
  );
  
  /**
   * Performs an API request with retry functionality
   * @param {Function} requestFn - Function that returns a promise for the API request
   * @param {Object} options - Options for the retry mechanism
   * @returns {Promise} - Promise that resolves with the API response
   */
  const withRetry = async (requestFn, options = {}) => {
    const { 
      maxRetries = MAX_RETRIES, 
      retryDelay = 300,
      shouldRetry = (error) => error?.response?.status >= 500 || error?.response?.status === 429,
      onRetry = null 
    } = options;
    
    let retries = 0;
    
    const executeRequest = async () => {
      try {
        return await requestFn();
      } catch (error) {
        // Check if we should retry based on the error and retry count
        if (shouldRetry(error) && retries < maxRetries) {
          retries++;
          
          // Exponential backoff
          const delay = Math.pow(2, retries) * retryDelay;
          
          if (onRetry) {
            onRetry(retries, maxRetries, delay, error);
          } else {
            console.log(`Retrying request (${retries}/${maxRetries}) after ${delay}ms...`);
          }
          
          // Wait before retrying
          await new Promise(resolve => setTimeout(resolve, delay));
          
          // Try again
          return executeRequest();
        }
        
        // If we've exhausted our retries or shouldn't retry, throw the error
        throw error;
      }
    };
    
    return executeRequest();
  };

  return {
    api,
    withRetry,
    // Expose cancel token functionality
    cancelToken: {
      create: createCancelToken,
      getCurrentToken: () => currentCancelToken,
      cancelAll: () => {
        if (currentCancelToken) {
          currentCancelToken.cancel('Operation canceled by user');
          currentCancelToken = null;
        }
      }
    },
    // API for loading state management
    loading: {
      onStart: onLoadingStart,
      onEnd: onLoadingEnd,
      offStart: offLoadingStart,
      offEnd: offLoadingEnd,
      isLoading: (requestId) => activeRequests.has(requestId),
      getActiveRequests: () => Array.from(activeRequests.keys()),
      getActiveCount: () => activeRequests.size,
      // New method to clear all loading states - useful on navigation
      clearAll: () => {
        const currentRequests = Array.from(activeRequests.keys());
        currentRequests.forEach(id => {
          trackRequest(id).ended();
        });
        activeRequests.clear();
      }
    },
    // Allow creating custom request trackers
    trackRequest
  };
};

const apiClient = createApiClient();
export const api = apiClient.api;
export const loadingTracker = apiClient.loading;
export const trackRequest = apiClient.trackRequest;

export default apiClient;
